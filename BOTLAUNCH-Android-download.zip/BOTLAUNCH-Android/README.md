# BOTLAUNCH Android — local dashboard + Node worker runner

BOTLAUNCH packages its dashboard and Node.js Mobile runtime into an Android app. It does not require a user-owned hosting/VPS or manually opening Termux. The app runs its local API on `127.0.0.1:8787` and keeps project data in the app's private storage.

## What was ported in this revision

- ZIP analysis, extraction and backup use the bundled `zip-utils.js` implementation (Node built-ins only); no external `zip`/`unzip` executable is called.
- ZIP extraction rejects unsafe paths, skips symlinks and `.git`, supports ZIP32 store/deflate entries, and enforces an uncompressed-size limit.
- Backup includes the workspace and project `home` data, while excluding `node_modules`, environment secrets (`env.json`), metadata, temporary template ZIP and run log.
- Bot execution uses a `worker_threads` worker rather than `child_process`, so a bot worker can be terminated without stopping the dashboard. The runtime limits execution to one bot at a time to avoid shared working-directory conflicts.
- Project ZIPs retain `node_modules` if provided. “Periksa dependencies” verifies that declared runtime dependencies exist in the workspace.
- The app refreshes its bundled server assets on launch, so an app update can pick up the newer backend.

## Important compatibility limits

This is **not** a full npm replacement. Node.js Mobile does not support `child_process` reliably/officially. Therefore this Android build cannot run `npm install` as a subprocess. Include a `node_modules` folder built for a compatible Android/Node runtime in the uploaded ZIP; otherwise dependency checking returns a clear error. Native addons, modules that require subprocesses, Chromium/Puppeteer, scripts that depend on shell commands, and complex npm `start` scripts may not work. The worker-thread support and third-party bot compatibility still need verification on a physical Android device with the exact Node.js Mobile release.

The bot worker is not a security sandbox: uploaded code runs with the app's process permissions. Only upload code you trust.

## Build APK

Push this directory to a GitHub repository and run **Actions → Build BOTLAUNCH Android APK**. The workflow downloads the official Node.js Mobile Android binaries, configures NDK/CMake, builds a debug APK and uploads it as an artifact.

## Validation performed in this workspace

- `node --check` passed for `server.js`, `zip-utils.js` and `bot-worker.js`.
- ZIP create/read/extract round-trip passed, and Python `zipfile.testzip()` reported no corruption.
- Local Node.js API smoke test passed: upload/analyze ZIP → prepare workspace → start a no-dependency test bot in a worker → capture logs → stop bot → create backup.
- **Not performed:** Gradle/APK build, installation on Android, Node.js Mobile worker-thread test, or real WhatsApp/Telegram/Discord connection. Do not treat those as verified until run on-device.
