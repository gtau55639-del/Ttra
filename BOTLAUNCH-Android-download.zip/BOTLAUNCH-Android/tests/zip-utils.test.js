'use strict';
const assert = require('assert');
const fs = require('fs/promises');
const os = require('os');
const path = require('path');
const zip = require('../app/src/main/assets/nodejs-project/zip-utils');
(async () => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'botlaunch-zip-test-'));
  try {
    const src = path.join(root, 'src'), out = path.join(root, 'out'), archive = path.join(root, 'sample.zip');
    await fs.mkdir(path.join(src, 'nested'), { recursive: true });
    await fs.writeFile(path.join(src, 'package.json'), '{"name":"smoke","dependencies":{}}');
    await fs.writeFile(path.join(src, 'index.js'), 'console.log("ok")');
    await fs.writeFile(path.join(src, 'nested', 'data.txt'), 'zip round-trip works');
    const created = await zip.createZip(src, archive);
    assert.strictEqual(created.count, 3);
    const entries = await zip.readZip(archive);
    assert.strictEqual(entries.length, 3);
    await zip.extractZip(archive, out);
    assert.strictEqual(await fs.readFile(path.join(out, 'nested', 'data.txt'), 'utf8'), 'zip round-trip works');
    console.log('zip-utils: PASS');
  } finally { await fs.rm(root, { recursive: true, force: true }); }
})().catch(e => { console.error(e); process.exitCode = 1; });
