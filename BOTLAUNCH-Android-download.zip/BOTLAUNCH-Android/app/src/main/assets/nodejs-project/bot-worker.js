'use strict';
const { parentPort, workerData } = require('worker_threads');
const path = require('path');
for (const [key, value] of Object.entries(workerData.env || {})) {
  if (typeof value === 'string') process.env[key] = value;
}
process.env.BOTLAUNCH_PROJECT_DIR = workerData.cwd;
const emit = (type, value) => { try { parentPort.postMessage({ type, text: String(value) }); } catch {} };
const oldLog = console.log.bind(console), oldInfo = console.info.bind(console), oldWarn = console.warn.bind(console), oldError = console.error.bind(console);
console.log = (...args) => emit('log', args.map(String).join(' '));
console.info = (...args) => emit('log', args.map(String).join(' '));
console.warn = (...args) => emit('log', args.map(String).join(' '));
console.error = (...args) => emit('error', args.map(String).join(' '));
process.on('uncaughtException', e => { emit('error', e && (e.stack || e.message) || e); });
process.on('unhandledRejection', e => { emit('error', e && (e.stack || e.message) || e); });
try {
  process.argv = [process.execPath, workerData.entry, ...(workerData.args || []).filter(x => x !== workerData.entry && !x.startsWith('-'))];
  require(path.resolve(workerData.entry));
  emit('log', '[botlaunch] entry point berhasil dimuat.');
} catch (e) {
  emit('error', e && (e.stack || e.message) || e);
  setImmediate(() => process.exitCode = 1);
}
