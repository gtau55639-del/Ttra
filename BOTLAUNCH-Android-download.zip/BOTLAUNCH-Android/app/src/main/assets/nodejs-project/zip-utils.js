'use strict';
// ZIP32 reader/writer using only Node built-ins (no unzip/zip binaries).
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const zlib = require('zlib');
const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); CRC_TABLE[n] = c >>> 0; }
function crc32(buf) { let c = 0xFFFFFFFF; for (const b of buf) c = CRC_TABLE[(c ^ b) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function findEocd(buf) { const min = Math.max(0, buf.length - 22 - 65535); for (let i = buf.length - 22; i >= min; i--) if (buf.readUInt32LE(i) === 0x06054b50) return i; throw new Error('ZIP tidak valid: EOCD tidak ditemukan.'); }
async function readZip(file, options = {}) {
  const buf = await fsp.readFile(file); const eocd = findEocd(buf);
  const disk = buf.readUInt16LE(eocd + 4), cdDisk = buf.readUInt16LE(eocd + 6), entries = buf.readUInt16LE(eocd + 10), cdSize = buf.readUInt32LE(eocd + 12), cdOffset = buf.readUInt32LE(eocd + 16);
  if (disk || cdDisk || entries === 0xFFFF || cdOffset === 0xFFFFFFFF || cdSize === 0xFFFFFFFF) throw new Error('ZIP multi-disk/ZIP64 tidak didukung.');
  if (cdOffset + cdSize > eocd || entries > 30000) throw new Error('Directory ZIP tidak valid.');
  const result = []; let off = cdOffset, totalUncompressed = 0;
  for (let i = 0; i < entries; i++) {
    if (off + 46 > buf.length || buf.readUInt32LE(off) !== 0x02014b50) throw new Error('Entry ZIP rusak.');
    const madeBy = buf.readUInt16LE(off + 4), flags = buf.readUInt16LE(off + 8), method = buf.readUInt16LE(off + 10), crc = buf.readUInt32LE(off + 16), compSize = buf.readUInt32LE(off + 20), size = buf.readUInt32LE(off + 24), nl = buf.readUInt16LE(off + 28), el = buf.readUInt16LE(off + 30), cl = buf.readUInt16LE(off + 32), ext = buf.readUInt32LE(off + 38), localOff = buf.readUInt32LE(off + 42);
    if (flags & 1) throw new Error('ZIP terenkripsi tidak didukung.');
    totalUncompressed += size;
    if (size > (options.maxEntryBytes || 500 * 1024 * 1024) || totalUncompressed > (options.maxTotalBytes || 500 * 1024 * 1024)) throw new Error('Batas ukuran ekstraksi ZIP terlampaui.');
    const name = buf.subarray(off + 46, off + 46 + nl).toString((flags & 0x800) ? 'utf8' : 'utf8');
    const unixMode = (madeBy >> 8) === 3 ? (ext >>> 16) : 0; const symlink = (unixMode & 0xF000) === 0xA000;
    if (localOff + 30 > buf.length || buf.readUInt32LE(localOff) !== 0x04034b50) throw new Error('Header file ZIP rusak.');
    const lnl = buf.readUInt16LE(localOff + 26), lel = buf.readUInt16LE(localOff + 28), start = localOff + 30 + lnl + lel, end = start + compSize;
    if (end > buf.length) throw new Error('Isi file ZIP terpotong.');
    let data;
    if (name.endsWith('/')) data = Buffer.alloc(0);
    else if (method === 0) data = buf.subarray(start, end);
    else if (method === 8) data = zlib.inflateRawSync(buf.subarray(start, end), { maxOutputLength: Math.max(size, 1) });
    else throw new Error(`Metode kompresi ZIP ${method} tidak didukung.`);
    if (data.length !== size || crc32(data) !== crc) throw new Error(`Checksum/ukuran ZIP tidak cocok: ${name}`);
    result.push({ name, size, data: Buffer.from(data), symlink, directory: name.endsWith('/') });
    off += 46 + nl + el + cl;
  }
  return result;
}
async function extractZip(file, destination, options = {}) {
  const entries = await readZip(file, { maxTotalBytes: options.maxBytes || 500 * 1024 * 1024, maxEntryBytes: options.maxBytes || 500 * 1024 * 1024 }); let total = 0, count = 0;
  await fsp.mkdir(destination, { recursive: true });
  for (const e of entries) {
    if (e.symlink || !e.name || e.name.includes('\0')) continue;
    const normalized = e.name.replace(/\\/g, '/');
    if (normalized.startsWith('/') || /^[A-Za-z]:/.test(normalized) || normalized.split('/').includes('..')) throw new Error(`Path berbahaya dalam ZIP: ${e.name}`);
    if (options.skip && options.skip(normalized)) continue;
    const out = path.resolve(destination, ...normalized.split('/'));
    const rel = path.relative(path.resolve(destination), out);
    if (rel.startsWith('..') || path.isAbsolute(rel)) throw new Error(`Path keluar dari workspace: ${e.name}`);
    if (e.directory) { await fsp.mkdir(out, { recursive: true }); continue; }
    total += e.size; count++;
    if (total > (options.maxBytes || 500 * 1024 * 1024) || count > (options.maxFiles || 30000)) throw new Error('Batas ekstraksi ZIP terlampaui.');
    await fsp.mkdir(path.dirname(out), { recursive: true }); await fsp.writeFile(out, e.data, { mode: 0o644 });
  }
  return { entries, total, count };
}
async function createZip(sourceDir, outputFile, options = {}) {
  const files = [];
  async function walk(dir, rel = '') {
    for (const e of await fsp.readdir(dir, { withFileTypes: true })) {
      if (e.isSymbolicLink()) continue;
      const r = rel ? rel + '/' + e.name : e.name;
      if (options.skip && options.skip(r)) continue;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) await walk(full, r);
      else if (e.isFile()) files.push({ name: r.replace(/\\/g, '/'), data: await fsp.readFile(full) });
    }
  }
  await walk(sourceDir);
  const locals = [], centrals = []; let offset = 0;
  for (const f of files) {
    const name = Buffer.from(f.name, 'utf8'); const compressed = zlib.deflateRawSync(f.data); const method = compressed.length < f.data.length ? 8 : 0; const payload = method === 8 ? compressed : f.data; const crc = crc32(f.data); const now = new Date();
    const dosTime = ((now.getHours() & 31) << 11) | ((now.getMinutes() & 63) << 5) | ((Math.floor(now.getSeconds() / 2)) & 31);
    const dosDate = (((Math.max(1980, now.getFullYear()) - 1980) & 127) << 9) | (((now.getMonth() + 1) & 15) << 5) | (now.getDate() & 31);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x800, 6); lh.writeUInt16LE(method, 8); lh.writeUInt16LE(dosTime, 10); lh.writeUInt16LE(dosDate, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(payload.length, 18); lh.writeUInt32LE(f.data.length, 22); lh.writeUInt16LE(name.length, 26);
    locals.push(lh, name, payload);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE((3 << 8) | 20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x800, 8); ch.writeUInt16LE(method, 10); ch.writeUInt16LE(dosTime, 12); ch.writeUInt16LE(dosDate, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(payload.length, 20); ch.writeUInt32LE(f.data.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE((0o100644 << 16) >>> 0, 38); ch.writeUInt32LE(offset, 42);
    centrals.push(ch, name); offset += lh.length + name.length + payload.length;
  }
  const cd = Buffer.concat(centrals); const local = Buffer.concat(locals); const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(local.length, 16);
  await fsp.mkdir(path.dirname(outputFile), { recursive: true }); await fsp.writeFile(outputFile, Buffer.concat([local, cd, end])); return { count: files.length, bytes: local.length + cd.length + end.length };
}
module.exports = { readZip, extractZip, createZip };
