#include <jni.h>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include "node.h"

extern "C" JNIEXPORT jint JNICALL
Java_com_botlaunch_app_BotRuntimeService_startNodeWithArguments(
        JNIEnv *env, jobject /* this */, jobjectArray arguments) {
    const jsize count = env->GetArrayLength(arguments);
    std::vector<std::string> values;
    values.reserve(static_cast<size_t>(count));
    size_t total = 0;
    for (jsize i = 0; i < count; ++i) {
        auto item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        const char *chars = env->GetStringUTFChars(item, nullptr);
        values.emplace_back(chars ? chars : "");
        total += values.back().size() + 1;
        if (chars) env->ReleaseStringUTFChars(item, chars);
        env->DeleteLocalRef(item);
    }
    char *buffer = static_cast<char *>(std::calloc(total, sizeof(char)));
    if (!buffer) return 1;
    std::vector<char *> argv;
    argv.reserve(values.size());
    char *cursor = buffer;
    for (const auto &value : values) {
        argv.push_back(cursor);
        std::memcpy(cursor, value.c_str(), value.size() + 1);
        cursor += value.size() + 1;
    }
    int result = node::Start(static_cast<int>(argv.size()), argv.data());
    std::free(buffer);
    return static_cast<jint>(result);
}
