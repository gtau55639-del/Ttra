package com.botlaunch.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class BotRuntimeService extends Service {
    private static final String CHANNEL_ID = "botlaunch_runtime";
    private static volatile boolean started = false;
    private Thread nodeThread;

    static {
        System.loadLibrary("node");
        System.loadLibrary("native-lib");
    }

    public native Integer startNodeWithArguments(String[] arguments);

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("BOTLAUNCH aktif")
                .setContentText("Runtime lokal berjalan di perangkat ini")
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setOngoing(true)
                .build();
        startForeground(8787, notification);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!started) {
            started = true;
            final String base = getFilesDir().getAbsolutePath() + "/botlaunch";
            nodeThread = new Thread(() -> {
                try {
                    String js = "process.env.HOME=" + quote(getFilesDir().getAbsolutePath()) + ";" +
                            "process.env.BOTLAUNCH_HOME=" + quote(getFilesDir().getAbsolutePath()+"/.botlaunch") + ";" +
                            "process.env.PORT='8787';process.env.BOTLAUNCH_HOST='127.0.0.1';" +
                            "process.chdir(" + quote(base) + ");require('./server.js');";
                    startNodeWithArguments(new String[]{"node", "-e", js});
                } catch (Throwable e) {
                    Log.e("BOTLAUNCH", "Node runtime gagal dimulai", e);
                    started = false;
                }
            }, "botlaunch-node");
            nodeThread.start();
        }
        return START_STICKY;
    }

    private static String quote(String value) {
        return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "BOTLAUNCH runtime", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
