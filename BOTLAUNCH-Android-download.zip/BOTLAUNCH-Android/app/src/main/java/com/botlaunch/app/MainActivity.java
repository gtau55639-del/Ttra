package com.botlaunch.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler handler = new Handler();
    private int attempts = 0;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        copyAssetTree("nodejs-project", new File(getFilesDir(), "botlaunch"));
        showLoading();
        Intent service = new Intent(this, BotRuntimeService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service); else startService(service);
        openDashboardWhenReady();
    }

    private void showLoading() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 28, 28, 28);
        root.setBackgroundColor(Color.rgb(12, 18, 32));
        TextView title = new TextView(this);
        title.setText("BOTLAUNCH"); title.setTextSize(28); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER);
        TextView info = new TextView(this);
        info.setText("Menyalakan runtime lokal…\nTidak menggunakan server online atau Termux.");
        info.setTextSize(15); info.setTextColor(Color.LTGRAY); info.setGravity(Gravity.CENTER); info.setPadding(0, 18, 0, 0);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(info, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private void openDashboardWhenReady() {
        handler.postDelayed(() -> {
            attempts++;
            if (web == null) {
                web = new WebView(this);
                WebSettings settings = web.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setDomStorageEnabled(true);
                settings.setAllowFileAccess(false);
                web.setWebChromeClient(new WebChromeClient());
                web.setWebViewClient(new WebViewClient() {
                    @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                        if (request.isForMainFrame() && attempts < 20) handler.postDelayed(() -> web.loadUrl("http://127.0.0.1:8787/"), 700);
                    }
                });
                setContentView(web);
            }
            web.loadUrl("http://127.0.0.1:8787/");
        }, 1800);
    }

    private void copyAssetTree(String assetPath, File destination) {
        try {
            String[] children = getAssets().list(assetPath);
            if (children != null && children.length > 0) {
                if (!destination.exists()) destination.mkdirs();
                for (String child : children) copyAssetTree(assetPath + "/" + child, new File(destination, child));
            } else {
                File parent = destination.getParentFile(); if (parent != null) parent.mkdirs();
                try (InputStream in = getAssets().open(assetPath); FileOutputStream out = new FileOutputStream(destination)) {
                    byte[] buffer = new byte[8192]; int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                }
            }
        } catch (Exception e) { android.util.Log.e("BOTLAUNCH", "Gagal menyalin aset " + assetPath, e); }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
