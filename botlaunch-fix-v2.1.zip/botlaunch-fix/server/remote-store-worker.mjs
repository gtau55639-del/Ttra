/*
 * Penyimpanan luar gratis untuk otopilot BOTLAUNCH — Cloudflare Worker + KV.
 * Tidak butuh server: kode ini jalan di Cloudflare. Menyimpan SATU snapshot (gzip) dari server BOTLAUNCH.
 *
 *   PUT /   (Bearer TOKEN)  -> simpan snapshot
 *   GET /   (Bearer TOKEN)  -> ambil snapshot (404 kalau belum ada)
 *
 * Binding yang dibutuhkan (lihat README):
 *   STORE  = KV namespace
 *   TOKEN  = secret / variable teks (sama dengan REMOTE_STORE_TOKEN di server)
 *
 * Batas KV: nilai maksimum 25 MiB. Add-on sudah membatasi cadangan luar di bawah itu (remoteMaxBytes).
 */
const KEY = 'botlaunch-snapshot';
const MAX_BYTES = 25 * 1024 * 1024 - 64 * 1024;

async function sameSecret(a, b) {
  const enc = new TextEncoder();
  const [x, y] = await Promise.all([
    crypto.subtle.digest('SHA-256', enc.encode(String(a))),
    crypto.subtle.digest('SHA-256', enc.encode(String(b))),
  ]);
  const ax = new Uint8Array(x), by = new Uint8Array(y);
  let diff = 0;
  for (let i = 0; i < ax.length; i++) diff |= ax[i] ^ by[i];
  return diff === 0;
}
const text = (body, status) => new Response(body, { status, headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' } });

export default {
  async fetch(req, env) {
    if (!env.TOKEN || String(env.TOKEN).length < 12) return text('TOKEN belum diset (minimal 12 karakter).', 500);
    if (!env.STORE) return text('KV binding STORE belum dipasang.', 500);
    const m = /^Bearer (.+)$/i.exec(req.headers.get('Authorization') || '');
    if (!m || !(await sameSecret(m[1], env.TOKEN))) return text('unauthorized', 401);

    if (req.method === 'GET') {
      const v = await env.STORE.get(KEY, 'arrayBuffer');
      if (!v) return text('belum ada cadangan', 404);
      return new Response(v, { status: 200, headers: { 'Content-Type': 'application/gzip', 'Cache-Control': 'no-store' } });
    }
    if (req.method === 'PUT' || req.method === 'POST') {
      const declared = Number(req.headers.get('Content-Length') || 0);
      if (declared > MAX_BYTES) return text('terlalu besar untuk KV (maks 25 MiB)', 413);
      const buf = await req.arrayBuffer();
      if (buf.byteLength === 0) return text('kosong', 400);
      if (buf.byteLength > MAX_BYTES) return text('terlalu besar untuk KV (maks 25 MiB)', 413);
      await env.STORE.put(KEY, buf);
      return text('ok', 200);
    }
    return text('method tidak didukung', 405);
  },
};
