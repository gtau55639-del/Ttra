'use strict';
/*
 * BOTLAUNCH sync-addon v2 — tanpa dependency, Node >= 18.
 *
 * ENDPOINT (ditambahkan ke server BOTLAUNCH yang sudah ada)
 *   GET  /api/health        (tanpa login)  -> untuk pinger + deteksi add-on oleh app
 *   GET  /api/sync/status   (Bearer token) -> marker data, jumlah file, status pemulihan
 *   GET  /api/sync/export   (Bearer token) -> snapshot folder data (gzip, di-stream) untuk disimpan di HP
 *   POST /api/sync/import   (Bearer token) -> kembalikan snapshot dari HP ke server
 *
 * "marker" = id acak di folder data. Disk server ke-reset (restart/redeploy/tidur di paket free)
 * -> marker hilang dan dibuat baru -> app di HP / server sendiri tahu data perlu dipulihkan.
 *
 * MODE OTOPILOT (opsional, tanpa HP): isi REMOTE_STORE_URL. Server lalu
 *   1. mengunggah snapshot ke penyimpanan luar tiap beberapa menit + saat SIGTERM,
 *   2. saat boot dengan disk kosong: mengunduh snapshot, memulihkan file, lalu
 *   3. menyalakan lagi bot yang tadinya jalan (install + start lewat API server sendiri).
 * Jadi bot hidup lagi walau HP mati dan kamu tidur.
 *
 * Pemakaian (Express):
 *   const sync = require('./sync-addon')({ dataDir: DATA_DIR, onImported: reloadData });
 *   app.use(sync.middleware);          // taruh PALING ATAS, sebelum body parser
 *   // ... setelah app.listen(...):
 *   sync.start();                      // keep-alive + otopilot
 * Pemakaian (http mentah):
 *   if (await sync.handle(req, res)) return;   // di awal request handler
 */
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');
const { StringDecoder } = require('string_decoder');

const BOOT_ID = crypto.randomBytes(6).toString('hex');
const STARTED_AT = Date.now();
const MARKER_FILE = '.sync-marker';
const RUNNING_FILE = '.sync-running.json';
const SKIP_DIRS = new Set(['node_modules', '.git', '.cache', '.npm', 'tmp', '.tmp']);
const SKIP_FILE = /\.(log|pid)$|\.sync-tmp-/i;
const MIN_TOKEN = 12;
const B64_SLICE = 3 * 256 * 1024;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function httpErr(status, message) {
  return Object.assign(new Error(message), { status });
}
function envBool(v, dflt) {
  if (v === undefined || v === '') return dflt;
  return !/^(0|false|no|off)$/i.test(String(v));
}
function envJson(v) {
  if (!v) return {};
  try { const j = JSON.parse(v); return j && typeof j === 'object' ? j : {}; } catch { return {}; }
}
function validJson(buf) {
  try { JSON.parse(buf.toString('utf8')); return true; } catch { return false; }
}
// Batas ukuran aliran data: putus dengan error kalau melewati max (anti gzip-bomb).
function byteCap(max, message) {
  let n = 0;
  return new Transform({
    transform(chunk, _enc, cb) {
      n += chunk.length;
      if (n > max) cb(httpErr(400, message)); else cb(null, chunk);
    },
  });
}
// Pecah aliran byte jadi baris teks (UTF-8 aman di batas chunk), tanpa readline.
async function* lines(stream) {
  const dec = new StringDecoder('utf8');
  let buf = '';
  for await (const chunk of stream) {
    buf += dec.write(chunk);
    let start = 0, i;
    while ((i = buf.indexOf('\n', start)) >= 0) { yield buf.slice(start, i); start = i + 1; }
    if (start) buf = buf.slice(start);
  }
  buf += dec.end();
  if (buf) yield buf;
}

function createSync(opts = {}) {
  const o = {
    prefix: '/api',
    dataDir: process.env.DATA_DIR || path.join(process.cwd(), 'data'),
    adminToken: process.env.ADMIN_TOKEN || '',
    maxFileBytes: 10 * 1024 * 1024,
    maxTotalBytes: 40 * 1024 * 1024,
    keepAliveMs: 9 * 60 * 1000, // harus < 15 menit (batas idle paket free Render)
    selfUrl: process.env.SELF_URL || process.env.RENDER_EXTERNAL_URL || '',
    onImported: null, // async ({files, bytes}) => muat ulang data di memori server

    // ---- otopilot (penyimpanan luar). Kosongkan remoteUrl untuk mematikan.
    remoteUrl: process.env.REMOTE_STORE_URL || '',
    remoteGetUrl: process.env.REMOTE_STORE_GET_URL || '', // default: sama dengan remoteUrl
    remoteToken: process.env.REMOTE_STORE_TOKEN || '',
    remoteHeaders: envJson(process.env.REMOTE_STORE_HEADERS),
    remotePutMethod: (process.env.REMOTE_STORE_PUT_METHOD || 'PUT').toUpperCase(),
    remoteMaxTotalBytes: 18 * 1024 * 1024, // isi mentah maksimum di cadangan luar
    remoteMaxBytes: 24 * 1024 * 1024,      // ukuran gzip maksimum yang diunggah (KV Cloudflare: 25 MiB)
    remoteTimeoutMs: 90 * 1000,
    tickMs: 5 * 60 * 1000,                 // siklus otopilot
    shutdownMs: 20 * 1000,                 // jatah waktu cadangan terakhir saat SIGTERM
    recoverBackoffMs: [5000, 10000, 20000, 40000, 60000, 60000],
    autoStartBots: undefined,              // default: nyala kalau remoteUrl diisi
    localUrl: process.env.LOCAL_URL || 'http://127.0.0.1:' + (process.env.PORT || 3000),
    healthPollMs: 2000,
    healthTimeoutMs: 3 * 60 * 1000,
    bootStartDelayMs: 15 * 1000,
    botActionTimeoutMs: 15 * 60 * 1000,
    log: (...a) => console.log('[sync]', ...a),
    ...opts,
  };
  o.prefix = o.prefix.replace(/\/+$/, '');
  const remoteOn = !!o.remoteUrl;
  const autoStart = o.autoStartBots === undefined ? envBool(process.env.AUTO_START_BOTS, remoteOn) : !!o.autoStartBots;
  const tokenOk = typeof o.adminToken === 'string' && o.adminToken.length >= MIN_TOKEN;
  if (o.adminToken && !tokenOk) o.log('ADMIN_TOKEN terlalu pendek (minimal ' + MIN_TOKEN + ' karakter): endpoint sync dimatikan.');

  const root = path.resolve(o.dataDir);
  fs.mkdirSync(root, { recursive: true });
  const markerPath = path.join(root, MARKER_FILE);
  const runningPath = path.join(root, RUNNING_FILE);
  // Disk baru/kosong = marker belum ada saat boot.
  const freshDisk = !fs.existsSync(markerPath);
  if (freshDisk) {
    fs.writeFileSync(markerPath, JSON.stringify({ id: crypto.randomBytes(8).toString('hex'), createdAt: new Date().toISOString() }));
  }
  const readMarker = () => {
    try { return JSON.parse(fs.readFileSync(markerPath, 'utf8')).id || ''; } catch { return ''; }
  };

  // ---------- kunci: satu operasi berat pada satu waktu ----------
  let locked = false;
  async function withLock(fn) {
    if (locked) throw httpErr(429, 'Ada proses sinkronisasi lain yang sedang berjalan.');
    locked = true;
    try { return await fn(); } finally { locked = false; }
  }
  async function tryLock(fn) {
    if (locked) return null;
    locked = true;
    try { return await fn(); } finally { locked = false; }
  }

  // ---------- baca folder ----------
  async function scan(visit) {
    async function rec(dir, rel) {
      let ents;
      try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch { return; }
      for (const e of ents) {
        if (e.isSymbolicLink()) continue;
        const abs = path.join(dir, e.name);
        const r = rel ? rel + '/' + e.name : e.name;
        if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) await rec(abs, r); }
        else if (e.isFile() && !SKIP_FILE.test(e.name)) await visit(abs, r);
      }
    }
    await rec(root, '');
  }

  async function stats() {
    let files = 0, bytes = 0;
    await scan(async (abs) => {
      try { const st = await fsp.stat(abs); files++; bytes += st.size; } catch { /* abaikan */ }
    });
    return { files, bytes };
  }

  // Rencana snapshot: file kecil didahulukan, supaya file penting (sesi, konfigurasi) tidak pernah
  // tergusur file besar ketika batas total tercapai.
  async function planSnapshot(maxTotal) {
    const all = [];
    await scan(async (abs, rel) => {
      let st;
      try { st = await fsp.stat(abs); } catch { return; }
      all.push({ abs, rel, size: st.size, mtimeMs: st.mtimeMs });
    });
    all.sort((a, b) => a.size - b.size || (a.rel < b.rel ? -1 : 1));
    const entries = [], skipped = [];
    let total = 0;
    for (const e of all) {
      if (e.size > o.maxFileBytes || total + e.size > maxTotal) { skipped.push(e.rel); continue; }
      total += e.size;
      entries.push(e);
    }
    const fp = crypto.createHash('sha1');
    for (const e of entries) fp.update(e.rel + '\0' + e.size + '\0' + Math.round(e.mtimeMs) + '\n');
    return { entries, skipped, bytes: total, fingerprint: fp.digest('hex') };
  }

  // Baca satu file sampai stabil. Bot (mis. Baileys) menulis file sesi kapan saja; file JSON yang
  // setengah tertulis akan merusak sesi kalau ikut dipulihkan, jadi dicoba lagi sampai valid.
  async function readStable(abs) {
    let last = null;
    for (let i = 0; i < 4; i++) {
      let st1, buf, st2;
      try { st1 = await fsp.stat(abs); buf = await fsp.readFile(abs); st2 = await fsp.stat(abs); } catch { return last; }
      last = { buf, mode: st2.mode & 0o777 };
      const steady = st1.size === st2.size && st1.mtimeMs === st2.mtimeMs && buf.length === st2.size;
      const jsonOk = !/\.json$/i.test(abs) || buf.length > 2 * 1024 * 1024 || validJson(buf);
      if (steady && jsonOk) return last;
      await sleep(120);
    }
    return last; // paling akhir: pakai apa adanya
  }

  // Format v2: satu objek JSON per baris (header, file..., baris "end"). Memori hanya sebesar satu file.
  async function* snapshotChunks(plan) {
    yield JSON.stringify({ v: 2, createdAt: new Date().toISOString(), marker: readMarker() }) + '\n';
    let files = 0;
    const late = [];
    for (const e of plan.entries) {
      const r = await readStable(e.abs);
      if (!r) continue;
      if (r.buf.length > o.maxFileBytes) { late.push(e.rel); continue; }
      files++;
      // base64 per irisan (kelipatan 3 byte -> tanpa padding di tengah): memori per file = ukuran file + ~1 MB
      yield '{"p":' + JSON.stringify(e.rel) + ',"m":' + r.mode + ',"d":"';
      for (let off = 0; off < r.buf.length; off += B64_SLICE) yield r.buf.subarray(off, off + B64_SLICE).toString('base64');
      yield '"}\n';
    }
    yield JSON.stringify({ end: true, files, skipped: plan.skipped.concat(late) }) + '\n';
  }
  const gzipStream = (plan) => Readable.from(snapshotChunks(plan), { objectMode: false });

  async function gzipPlan(plan) {
    const gz = zlib.createGzip();
    const chunks = [];
    const done = pipeline(gzipStream(plan), gz);
    done.catch(() => {});
    for await (const c of gz) chunks.push(c);
    await done;
    return Buffer.concat(chunks);
  }

  // ---------- pulihkan ----------
  // Mengembalikan array bagian path yang aman, atau null.
  function safeParts(p) {
    if (typeof p !== 'string' || !p || p.length > 400) return null;
    if (p.includes('\0') || p.includes('\\') || p.startsWith('/')) return null;
    const parts = p.split('/');
    if (parts.some((s) => !s || s === '.' || s === '..')) return null;
    if (parts.slice(0, -1).some((s) => SKIP_DIRS.has(s))) return null;
    return parts;
  }
  // Buat folder satu per satu; tolak kalau ada symlink di jalur (tidak boleh keluar dari DATA_DIR).
  async function ensureDir(parts, created) {
    let cur = root;
    for (const s of parts) {
      cur = path.join(cur, s);
      let st;
      try { st = await fsp.lstat(cur); }
      catch (e) {
        if (e.code !== 'ENOENT') throw e;
        try { await fsp.mkdir(cur); if (created) created.push(cur); } catch (e2) { if (e2.code !== 'EEXIST') throw e2; }
        continue;
      }
      if (st.isSymbolicLink() || !st.isDirectory()) throw new Error('jalur tidak aman');
    }
    return cur;
  }

  async function importGz(gzBuf) {
    const maxOut = Math.ceil(o.maxTotalBytes * 1.5) + 2 * 1024 * 1024;
    const staged = [];       // file sementara yang baru di-rename setelah snapshot terbukti utuh
    const created = [];      // folder yang dibuat import ini (dibersihkan kalau import gagal)
    const rejected = [];
    let header = null, ended = false, endInfo = null, seq = 0;

    async function stage(f) {
      const parts = f && typeof f === 'object' ? safeParts(f.p) : null;
      if (!parts || typeof f.d !== 'string') { rejected.push(String(f && f.p).slice(0, 120)); return; }
      try {
        const dir = await ensureDir(parts.slice(0, -1), created);
        const target = path.join(dir, parts[parts.length - 1]);
        const buf = Buffer.from(f.d, 'base64');
        const tmp = target + '.sync-tmp-' + process.pid + '-' + (seq++);
        await fsp.writeFile(tmp, buf, { mode: (Number(f.m) & 0o777) || 0o644 }); // tanpa setuid/setgid
        staged.push({ tmp, target, size: buf.length, isMarker: parts.join('/') === MARKER_FILE });
      } catch { rejected.push(String(f.p).slice(0, 120)); }
    }
    const discard = async () => {
      await Promise.all(staged.map((s) => fsp.unlink(s.tmp).catch(() => {})));
      for (const d of created.slice().reverse()) await fsp.rmdir(d).catch(() => {}); // hanya yang masih kosong
    };

    try {
      const gunzip = zlib.createGunzip();
      const cap = byteCap(maxOut, 'Snapshot terlalu besar.');
      const piped = pipeline(Readable.from([gzBuf], { objectMode: false }), gunzip, cap);
      piped.catch(() => {});
      for await (const line of lines(cap)) {
        if (!line.trim()) continue;
        let obj;
        try { obj = JSON.parse(line); } catch { throw httpErr(400, 'Snapshot rusak.'); }
        if (!header) {
          if (obj && obj.v === 1 && Array.isArray(obj.files)) {      // format lama (satu JSON besar)
            header = obj;
            for (const f of obj.files) await stage(f);
            ended = true; endInfo = { skipped: obj.skipped || [] };
          } else if (obj && obj.v === 2) header = obj;
          else throw httpErr(400, 'Format snapshot tidak dikenal.');
          continue;
        }
        if (ended) throw httpErr(400, 'Ada data setelah akhir snapshot.');
        if (obj && obj.end === true) { ended = true; endInfo = obj; continue; }
        await stage(obj);
      }
      if (!ended) throw httpErr(400, 'Snapshot terpotong (tidak lengkap).');
    } catch (e) {
      await discard();
      if (e && e.status) throw e;
      throw httpErr(400, 'Snapshot rusak atau terlalu besar.');
    }

    // Terbukti utuh -> pasang. Marker dipasang PALING AKHIR: marker cocok = pemulihan selesai.
    let written = 0, bytes = 0;
    const order = staged.filter((s) => !s.isMarker).concat(staged.filter((s) => s.isMarker));
    for (const s of order) {
      try { await fsp.rename(s.tmp, s.target); written++; bytes += s.size; }
      catch { rejected.push(path.relative(root, s.target).slice(0, 120)); await fsp.unlink(s.tmp).catch(() => {}); }
    }
    let reload = 'none';
    if (typeof o.onImported === 'function') {
      try { await o.onImported({ files: written, bytes }); reload = 'ok'; }
      catch (e) { reload = 'error'; o.log('onImported gagal:', e && e.message); }
    }
    return {
      ok: true, files: written, bytes, rejected, reload, marker: readMarker(),
      skipped: Array.isArray(endInfo && endInfo.skipped) ? endInfo.skipped.length : 0,
    };
  }

  // ---------- util HTTP ----------
  function cors(res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, POST, OPTIONS');
    res.setHeader('Access-Control-Expose-Headers', 'X-Sync-Marker, X-Sync-Files, X-Sync-Bytes, X-Sync-Skipped');
    res.setHeader('Cache-Control', 'no-store');
  }
  function sendJson(res, code, obj, head) {
    const body = Buffer.from(JSON.stringify(obj));
    res.statusCode = code;
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Length', body.length);
    res.end(head ? undefined : body);
  }
  // Kalau unggahan kebesaran: balas 413 SEKARANG, tapi sisa unggahan tetap dikuras (dibuang) sampai batas
  // DRAIN_MAX. Menutup koneksi saat klien masih mengirim membuat klien menerima ECONNRESET / "Failed to fetch"
  // dan 413 tidak pernah sampai.
  const DRAIN_MAX = 64 * 1024 * 1024;
  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      let n = 0, tooBig = false;
      req.on('data', (c) => {
        n += c.length;
        if (n > limit) {
          if (!tooBig) { tooBig = true; chunks.length = 0; reject(httpErr(413, 'Snapshot terlalu besar.')); }
          if (n > limit + DRAIN_MAX) req.destroy(); // pengunggah nakal: putus
          return;
        }
        if (!tooBig) chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  function authState(req) {
    if (!tokenOk) return 'no-token';
    const m = /^Bearer (.+)$/i.exec(req.headers.authorization || '');
    if (!m) return false;
    const a = crypto.createHash('sha256').update(m[1]).digest();
    const b = crypto.createHash('sha256').update(o.adminToken).digest();
    return crypto.timingSafeEqual(a, b);
  }

  // true = request sudah ditangani add-on
  async function handle(req, res) {
    let p;
    try { p = new URL(req.originalUrl || req.url, 'http://x').pathname.replace(/\/+$/, '') || '/'; }
    catch { return false; } // URL tidak valid: serahkan ke server utama, jangan sampai crash
    const isHealth = p === o.prefix + '/health';
    if (!isHealth && !p.startsWith(o.prefix + '/sync/')) return false;
    cors(res);
    if (req.method === 'OPTIONS') { res.statusCode = 204; res.end(); return true; }
    try {
      if (isHealth) {
        if (req.method !== 'GET' && req.method !== 'HEAD') throw httpErr(405, 'Method tidak didukung.');
        sendJson(res, 200, {
          ok: true, sync: true, bootId: BOOT_ID, startedAt: STARTED_AT,
          uptimeSec: Math.round((Date.now() - STARTED_AT) / 1000),
        }, req.method === 'HEAD');
        return true;
      }
      const a = authState(req);
      if (a === 'no-token') throw httpErr(403, 'ADMIN_TOKEN belum diset di server (minimal ' + MIN_TOKEN + ' karakter).');
      if (!a) throw httpErr(401, 'Token tidak valid.');

      if (p === o.prefix + '/sync/status' && req.method === 'GET') {
        const s = await stats();
        sendJson(res, 200, {
          ok: true, bootId: BOOT_ID, marker: readMarker(), files: s.files, bytes: s.bytes,
          autopilot: publicState(),
        });
      } else if (p === o.prefix + '/sync/export' && req.method === 'GET') {
        await withLock(async () => {
          const plan = await planSnapshot(o.maxTotalBytes);
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/gzip');
          res.setHeader('X-Sync-Marker', readMarker());
          res.setHeader('X-Sync-Files', String(plan.entries.length));
          res.setHeader('X-Sync-Bytes', String(plan.bytes));
          res.setHeader('X-Sync-Skipped', String(plan.skipped.length));
          await pipeline(gzipStream(plan), zlib.createGzip(), res);
        });
      } else if (p === o.prefix + '/sync/import' && req.method === 'POST') {
        const body = await readBody(req, o.maxTotalBytes + 5 * 1024 * 1024);
        sendJson(res, 200, await withLock(() => importGz(body)));
      } else {
        throw httpErr(404, 'Endpoint tidak ditemukan.');
      }
    } catch (e) {
      if (!res.headersSent) {
        sendJson(res, e.status || 500, { error: e.message || 'Kesalahan server.' });
      } else { try { res.destroy(); } catch { /* sudah putus */ } } // aliran terputus di tengah: jangan kirim gzip "utuh"
    }
    return true;
  }

  function middleware(req, res, next) {
    handle(req, res).then((done) => { if (!done) next(); }).catch(next);
  }

  // Server ping dirinya sendiri lewat URL publik supaya hitungan idle 15 menit terus direset.
  // Tidak bisa membangunkan server yang sudah tidur -> tetap pakai pinger eksternal.
  function startKeepAlive() {
    if (!o.selfUrl) { o.log('keep-alive dilewati: SELF_URL / RENDER_EXTERNAL_URL tidak ada.'); return null; }
    const url = o.selfUrl.replace(/\/+$/, '') + o.prefix + '/health';
    const t = setInterval(() => {
      fetch(url, { signal: AbortSignal.timeout(20000) }).catch(() => {});
    }, o.keepAliveMs);
    if (t.unref) t.unref();
    o.log('keep-alive aktif ->', url, 'tiap', Math.round(o.keepAliveMs / 60000), 'menit');
    return t;
  }

  // =====================================================================
  //                         OTOPILOT (tanpa HP)
  // =====================================================================
  const state = {
    recovery: remoteOn ? 'pending' : 'off', // pending | restored | no-remote-snapshot | intact-disk | failed | off
    lastUpload: null, lastError: '', recoveredFiles: 0, botsStarted: 0,
  };
  let uploadAllowed = !remoteOn ? false : !freshDisk; // disk baru: dilarang unggah sebelum urusan pemulihan selesai
  let recoveryDone = false;
  let lastFp = '', lastKnownFiles = 0, shrinkStrikes = 0, ticking = false, shuttingDown = false;
  const retry = new Map(); // id bot -> sisa percobaan menyalakan
  let timer = null, started = false;

  function publicState() {
    return {
      remote: remoteOn, recovery: state.recovery, autoStartBots: autoStart,
      lastUpload: state.lastUpload, lastError: state.lastError,
      recoveredFiles: state.recoveredFiles, botsStarted: state.botsStarted, freshDisk,
    };
  }

  // ---- penyimpanan luar (HTTP biasa: PUT unggah, GET unduh) ----
  function rHeaders(extra) {
    const h = { ...o.remoteHeaders, ...extra };
    if (o.remoteToken) h.Authorization = 'Bearer ' + o.remoteToken;
    return h;
  }
  async function remotePut(gz) {
    const r = await fetch(o.remoteUrl, {
      method: o.remotePutMethod, headers: rHeaders({ 'Content-Type': 'application/gzip' }), body: gz,
      signal: AbortSignal.timeout(o.remoteTimeoutMs),
    });
    if (!r.ok) throw new Error('penyimpanan luar menolak unggahan (HTTP ' + r.status + ')');
  }
  async function remoteGet() {
    const r = await fetch(o.remoteGetUrl || o.remoteUrl, { headers: rHeaders(), signal: AbortSignal.timeout(o.remoteTimeoutMs) });
    if (r.status === 404 || r.status === 204) return null;
    if (!r.ok) throw new Error('penyimpanan luar menolak unduhan (HTTP ' + r.status + ')');
    const len = Number(r.headers.get('content-length') || 0);
    if (len > o.maxTotalBytes * 2) throw new Error('cadangan luar terlalu besar');
    const buf = Buffer.from(await r.arrayBuffer());
    return buf.length ? buf : null;
  }

  // ---- API server sendiri (loopback), sama seperti yang dipakai app di HP ----
  async function local(method, pathname, ms) {
    return fetch(o.localUrl.replace(/\/+$/, '') + o.prefix + pathname, {
      method, headers: { Authorization: 'Bearer ' + o.adminToken }, signal: AbortSignal.timeout(ms || 30000),
    });
  }
  async function localProjects() {
    try {
      const r = await local('GET', '/projects');
      if (!r.ok) return null;
      const j = await r.json();
      return j && Array.isArray(j.projects) ? j.projects : null;
    } catch { return null; }
  }
  async function startBot(id) {
    for (const action of ['install', 'start']) {
      const r = await local('POST', '/projects/' + encodeURIComponent(id) + '/' + action, o.botActionTimeoutMs);
      if (!r.ok) {
        const j = await r.json().catch(() => ({}));
        throw new Error(j.error || action + ' gagal (HTTP ' + r.status + ')');
      }
    }
  }
  async function waitHealthy() {
    const until = Date.now() + o.healthTimeoutMs;
    while (Date.now() < until) {
      try { const r = await local('GET', '/health', 5000); if (r.ok) return true; } catch { /* belum siap */ }
      await sleep(o.healthPollMs);
    }
    return false;
  }

  // ---- catatan "bot mana yang harus nyala" (ikut masuk snapshot karena ada di DATA_DIR) ----
  function readIntent() {
    try {
      const j = JSON.parse(fs.readFileSync(runningPath, 'utf8'));
      return Array.isArray(j.ids) ? j.ids.filter((x) => typeof x === 'string').slice(0, 100) : [];
    } catch { return []; }
  }
  function writeIntent(ids) {
    const next = Array.from(new Set(ids)).sort();
    const cur = readIntent().slice().sort();
    if (next.length === cur.length && next.every((x, i) => x === cur[i])) return false;
    const tmp = runningPath + '.sync-tmp-' + process.pid;
    fs.writeFileSync(tmp, JSON.stringify({ ids: next, at: new Date().toISOString() }));
    fs.renameSync(tmp, runningPath);
    return true;
  }
  async function updateIntent() {
    const list = await localProjects();
    if (!list || list.length === 0) return; // gagal baca / belum ada proyek: jangan timpa catatan lama
    const online = list.filter((p) => p.runtimeStatus === 'online').map((p) => String(p.projectId));
    for (const [id, left] of Array.from(retry.entries())) {
      if (online.includes(id)) { retry.delete(id); continue; }
      if (left <= 0) { retry.delete(id); continue; }
      retry.set(id, left - 1);
      try { await startBot(id); state.botsStarted++; retry.delete(id); online.push(id); o.log('bot', id, 'berhasil dinyalakan (percobaan ulang)'); }
      catch (e) { o.log('bot', id, 'belum bisa dinyalakan:', e.message); }
    }
    writeIntent(online.concat(Array.from(retry.keys())));
  }

  // ---- 1) pemulihan saat boot ----
  async function recover() {
    if (!remoteOn) { state.recovery = 'off'; return; }
    if (!freshDisk) { state.recovery = 'intact-disk'; uploadAllowed = true; return; }
    const waits = o.recoverBackoffMs;
    for (let i = 0; i <= waits.length; i++) {
      try {
        const gz = await remoteGet();
        if (!gz) { state.recovery = 'no-remote-snapshot'; uploadAllowed = true; o.log('belum ada cadangan di penyimpanan luar; mulai dari kosong.'); return; }
        const r = await withLock(() => importGz(gz));
        state.recovery = 'restored'; state.recoveredFiles = r.files; lastKnownFiles = r.files; uploadAllowed = true;
        state.lastError = '';
        o.log('dipulihkan dari penyimpanan luar:', r.files, 'file');
        return;
      } catch (e) {
        state.lastError = 'pemulihan: ' + e.message;
        o.log('pemulihan gagal (' + (i + 1) + '/' + (waits.length + 1) + '):', e.message);
        if (i < waits.length) await sleep(waits[i]);
      }
    }
    state.recovery = 'failed'; // uploadAllowed tetap false: JANGAN menimpa cadangan bagus dengan disk kosong
    o.log('pemulihan belum berhasil; akan dicoba lagi di siklus berikutnya. Unggahan ditahan.');
  }

  // ---- 2) nyalakan lagi bot yang tadinya jalan ----
  async function restartBots() {
    const ids = readIntent();
    if (!autoStart || !tokenOk || !ids.length) { recoveryDone = true; return; }
    o.log('menyalakan lagi bot:', ids.join(', '));
    if (!(await waitHealthy())) { o.log('server lokal tidak siap; bot tidak dinyalakan.'); recoveryDone = true; return; }
    await sleep(o.bootStartDelayMs);
    let list = await localProjects();
    for (let i = 0; i < 3 && !list; i++) { await sleep(Math.min(5000, o.bootStartDelayMs)); list = await localProjects(); }
    if (!list) { o.log('daftar proyek tidak terbaca; catatan bot dipertahankan.'); recoveryDone = true; return; }
    for (const id of ids) {
      const p = list.find((x) => String(x.projectId) === id);
      if (p && p.runtimeStatus === 'online') continue;
      try { await startBot(id); state.botsStarted++; o.log('bot', id, 'menyala'); }
      catch (e) { retry.set(id, 3); o.log('bot', id, 'gagal dinyalakan (akan dicoba lagi):', e.message); }
    }
    recoveryDone = true;
  }

  // ---- 3) cadangan ke luar ----
  async function backupRemote(opt = {}) {
    if (!remoteOn || !uploadAllowed) return { skipped: 'not-allowed' };
    try {
      const out = await tryLock(async () => {
        const plan = await planSnapshot(o.remoteMaxTotalBytes);
        if (!opt.force && plan.fingerprint === lastFp) return { skipped: 'unchanged' };
        // Pengaman: data tiba-tiba jauh lebih sedikit. Tahan, kecuali kondisi itu bertahan 3 siklus berturut-turut.
        if (lastKnownFiles >= 5 && plan.entries.length < lastKnownFiles * 0.3) {
          if (++shrinkStrikes < 3) { o.log('data jauh lebih sedikit dari cadangan sebelumnya; unggahan ditahan (' + shrinkStrikes + '/3).'); return { skipped: 'shrink' }; }
        }
        shrinkStrikes = 0;
        const gz = await gzipPlan(plan);
        if (gz.length > o.remoteMaxBytes) throw new Error('cadangan ' + (gz.length / 1048576).toFixed(1) + ' MB melebihi remoteMaxBytes; kurangi isi DATA_DIR atau naikkan batas');
        await remotePut(gz);
        lastFp = plan.fingerprint; lastKnownFiles = plan.entries.length;
        state.lastUpload = { at: new Date().toISOString(), files: plan.entries.length, bytes: gz.length };
        state.lastError = '';
        return { ok: true, files: plan.entries.length, bytes: gz.length };
      });
      return out || { skipped: 'busy' };
    } catch (e) {
      state.lastError = 'unggah: ' + e.message;
      o.log('unggah gagal:', e.message);
      return { error: e.message };
    }
  }

  async function tick() {
    if (ticking || shuttingDown) return;
    ticking = true;
    try {
      if (remoteOn && state.recovery === 'failed') {
        await recover();
        if (state.recovery !== 'failed') await restartBots();
      }
      if (recoveryDone && tokenOk) await updateIntent();
      if (remoteOn) await backupRemote();
    } catch (e) { o.log('siklus otopilot gagal:', e && e.message); }
    finally { ticking = false; }
  }

  function installShutdown() {
    process.on('SIGTERM', async () => {
      if (shuttingDown) return;
      shuttingDown = true;
      o.log('SIGTERM: cadangan terakhir ke penyimpanan luar...');
      try { await Promise.race([backupRemote(), sleep(o.shutdownMs)]); } catch { /* abaikan */ }
      // Kalau tidak ada handler SIGTERM lain, perilaku bawaan Node (keluar) harus tetap berlaku.
      if (process.listenerCount('SIGTERM') <= 1) process.exit(0);
    });
  }

  // Satu pintu: keep-alive + otopilot. Panggil setelah server mulai listen.
  function start() {
    if (started) return;
    started = true;
    startKeepAlive();
    if (!remoteOn && !autoStart) return;
    (async () => {
      await recover();
      if (state.recovery !== 'failed') await restartBots();
      timer = setInterval(() => { tick(); }, o.tickMs);
      if (timer.unref) timer.unref();
    })().catch((e) => o.log('otopilot berhenti:', e && e.message));
    if (remoteOn) installShutdown();
  }
  function stop() { if (timer) clearInterval(timer); timer = null; }

  return {
    handle, middleware, start, stop, startKeepAlive, readMarker, root,
    // dipakai tes / integrasi khusus
    recover, restartBots, backupRemote, tick, updateIntent, importGz,
    state: () => ({ ...publicState(), recoveryDone, uploadAllowed }),
  };
}

module.exports = createSync;
module.exports.createSync = createSync;
module.exports.BOOT_ID = BOOT_ID;
