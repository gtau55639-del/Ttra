'use strict';
/*
 * Tes ujung-ke-ujung script HP (phone-sync.js) di Chromium sungguhan melawan server + add-on nyata.
 * Butuh Playwright (npm i -D playwright). Tanpa Playwright tes ini dilewati.
 */
let chromium;
try { ({ chromium } = require('playwright')); } catch { console.log('DILEWATI: playwright tidak terpasang (npm i -D playwright && npx playwright install chromium)'); process.exit(0); }
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const createSync = require('../server/sync-addon');

const TOKEN = 'token-rahasia-123456';
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'ph-'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const json = (res, obj, code) => { res.statusCode = code || 200; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(obj)); };
const w = (dir, p, c) => { const f = path.join(dir, p); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, c); };
const PHONE_JS = fs.readFileSync(path.join(__dirname, '../app/public/phone-sync.js'));
const PAGE = '<!doctype html><html><head><meta charset="utf-8"><script defer src="/phone-sync.js"></script></head><body><div id="root">app</div></body></html>';

// server "host" tiruan. withAddon=false meniru server yang belum dipasangi add-on (SPA mengembalikan index.html).
async function makeHost({ withAddon = true, projects = [] } = {}) {
  const h = { projects, calls: [], dir: tmp(), listFail: false, withAddon };
  const mount = () => {
    h.sync = createSync({
      dataDir: h.dir, adminToken: TOKEN, log: () => {},
      onImported: async () => { // seperti server asli: baca ulang dari disk
        try { h.projects = JSON.parse(fs.readFileSync(path.join(h.dir, 'projects.json'), 'utf8')).projects.map((p) => ({ ...p, runtimeStatus: 'offline' })); } catch { /* */ }
      },
    });
  };
  mount();
  h.resetDisk = () => { h.dir = tmp(); h.projects = []; mount(); }; // meniru Render free: disk kosong
  h.server = http.createServer(async (req, res) => {
    if (h.withAddon && (await h.sync.handle(req, res))) return;
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/phone-sync.js') { res.setHeader('Content-Type', 'application/javascript'); return res.end(PHONE_JS); }
    if (u.pathname.startsWith('/api/')) {
      if (h.withAddon === false && u.pathname === '/api/health') { res.setHeader('Content-Type', 'text/html'); return res.end(PAGE); } // SPA catch-all
      if ((req.headers.authorization || '') !== 'Bearer ' + TOKEN) return json(res, { error: 'auth' }, 401);
      if (req.method === 'GET' && u.pathname === '/api/projects') return h.listFail ? json(res, { error: 'down' }, 503) : json(res, { projects: h.projects });
      const m = /^\/api\/projects\/([^/]+)\/(install|start)$/.exec(u.pathname);
      if (req.method === 'POST' && m) {
        h.calls.push(m[2] + ':' + m[1]);
        const p = h.projects.find((x) => x.projectId === m[1]);
        if (p && m[2] === 'start') p.runtimeStatus = 'online';
        return json(res, { ok: true });
      }
      return json(res, { error: 'nf' }, 404);
    }
    res.setHeader('Content-Type', 'text/html'); res.end(PAGE);
  });
  await new Promise((r) => h.server.listen(0, '127.0.0.1', r));
  h.url = 'http://127.0.0.1:' + h.server.address().port;
  return h;
}

let failed = 0;
async function step(name, fn) {
  try { await fn(); console.log('ok   ' + name); }
  catch (e) { failed++; console.log('GAGAL ' + name + '\n       -> ' + String(e.message).split('\n')[0].slice(0, 160)); }
}

(async () => {
  const browser = await chromium.launch();
  const open = async (host, { token = TOKEN, cfg = {} } = {}) => {
    const ctx = await browser.newContext();
    const page = await ctx.newPage();
    page.on('dialog', (d) => d.accept());
    await page.addInitScript(({ t, c }) => {
      try { localStorage.setItem('botlaunch.token', t); } catch (e) { /* */ }
      window.BOTLAUNCH_SYNC = Object.assign({ firstTickMs: 3600000, tickMs: 3600000, wakeTimeoutMs: 5000 }, c); // tick manual saja
    }, { t: token, c: cfg });
    await page.goto(host.url + '/');
    await page.waitForFunction(() => !!window.BotlaunchPhoneSync);
    return page;
  };
  const chip = (page) => page.evaluate(() => document.querySelector('#ps-chip span').textContent);
  const meta = (page) => page.evaluate(() => window.BotlaunchPhoneSync.meta());
  const tick = (page, force) => page.evaluate((f) => window.BotlaunchPhoneSync.tick(f), !!force);

  const host = await makeHost({ projects: [{ projectId: 'p1', name: 'Bot Satu', runtimeStatus: 'online' }, { projectId: 'p2', name: 'Bot Dua', runtimeStatus: 'offline' }] });
  w(host.dir, 'projects.json', JSON.stringify({ projects: [{ projectId: 'p1', name: 'Bot Satu' }, { projectId: 'p2', name: 'Bot Dua' }] }));
  w(host.dir, 'projects/p1/workspace/index.js', 'console.log(1)');
  w(host.dir, 'projects/p1/workspace/session/creds.json', '{"noiseKey":"sesi-rahasia"}');
  w(host.dir, 'projects/p2/workspace/index.js', 'console.log(2)');
  for (let i = 0; i < 8; i++) w(host.dir, 'data/f' + i + '.json', '{"i":' + i + '}');
  let page, marker1;

  await step('1 cadangan di HP (IndexedDB) + catatan bot jalan = [p1]; chip hijau', async () => {
    page = await open(host);
    await tick(page, true);
    const m = await meta(page);
    assert.ok(m && m.files >= 5, 'cadangan harus ada: ' + JSON.stringify(m));
    assert.deepEqual(m.running, ['p1']);
    assert.match(await chip(page), /^HP \u2713/);
    marker1 = m.marker;
  });

  await step('2 disk server hilang -> data + sesi pulih, bot p1 install+start otomatis', async () => {
    host.resetDisk();
    assert.equal(host.projects.length, 0);
    await tick(page, false);
    assert.equal(fs.readFileSync(path.join(host.dir, 'projects/p1/workspace/session/creds.json'), 'utf8'), '{"noiseKey":"sesi-rahasia"}');
    assert.equal(host.sync.readMarker(), marker1);
    assert.deepEqual(host.calls, ['install:p1', 'start:p1']);
    assert.match(await chip(page), /Dipulihkan \d+ file \u00b7 1 bot nyala/);
  });

  await step('3 pengaman backup: otomatis menahan, "Cadangkan sekarang" boleh menimpa (dulu macet selamanya)', async () => {
    const page3 = await open(host, { cfg: { snapshotMs: 0 } });
    await tick(page3, true); // cadangan baru dari kondisi sehat
    for (const f of ['projects/p2/workspace/index.js', 'projects/p1/workspace/index.js', 'projects/p1/workspace/session/creds.json', 'data', 'projects.json']) fs.rmSync(path.join(host.dir, f), { recursive: true });
    w(host.dir, 'sisa.txt', 'x');
    await tick(page3, false);
    assert.match(await chip(page3), /Gagal: Data server jauh lebih sedikit/);
    const kept = await meta(page3);
    assert.ok(kept.files >= 5, 'cadangan lama harus dipertahankan');
    await page3.evaluate(() => window.BotlaunchPhoneSync.backupNow()); // tombol "Cadangkan sekarang"
    const now = await meta(page3);
    assert.ok(now.files < kept.files, 'cadangan manual harus menimpa');
    assert.match(await chip(page3), /^HP \u2713/);
  });

  const host4 = await makeHost({ projects: [{ projectId: 'b1', name: 'B', runtimeStatus: 'online' }] });
  w(host4.dir, 'projects.json', JSON.stringify({ projects: [{ projectId: 'b1' }] }));
  w(host4.dir, 'a/1.txt', '1'); w(host4.dir, 'a/2.txt', '2');
  await step('4 API daftar bot gagal -> catatan bot jalan tidak ditimpa kosong (dulu terhapus)', async () => {
    const page4 = await open(host4);
    await tick(page4, true);
    assert.deepEqual((await meta(page4)).running, ['b1']);
    host4.listFail = true;
    await tick(page4, true);
    assert.deepEqual((await meta(page4)).running, ['b1'], 'catatan lama harus dipertahankan saat API gagal');
    host4.listFail = false;
  });

  const host5 = await makeHost({ withAddon: false });
  await step('5 server tanpa add-on (SPA balas HTML) -> "belum pasang sync-addon" (dulu: salah "tidak terjangkau")', async () => {
    const page5 = await open(host5, { cfg: { wakeHtmlRetries: 2, wakeHtmlGapMs: 50, wakeRetries: 2 } });
    await tick(page5, true);
    assert.match(await chip(page5), /belum pasang sync-addon/);
  });

  await step('6 token salah -> pesan jelas', async () => {
    const page6 = await open(host4, { token: 'token-yang-salah-123' });
    await tick(page6, true);
    assert.match(await chip(page6), /Token salah/);
  });

  await step('7 server mati -> "Server tidak terjangkau"', async () => {
    const ctx7 = await browser.newContext();
    const page7 = await ctx7.newPage();
    await page7.route('**/api/**', (r) => r.abort('connectionrefused'));
    await page7.addInitScript(() => { localStorage.setItem('botlaunch.token', 'token-rahasia-123456'); window.BOTLAUNCH_SYNC = { firstTickMs: 3600000, tickMs: 3600000, wakeTimeoutMs: 1000, wakeRetries: 2 }; });
    await page7.goto(host4.url + '/'); await page7.waitForFunction(() => !!window.BotlaunchPhoneSync);
    await tick(page7, true);
    assert.match(await chip(page7), /Server tidak terjangkau/);
  });

  await step('8 panel menampilkan status otopilot server', async () => {
    await page.evaluate(() => document.getElementById('ps-chip').click());
    const panel = await page.evaluate(() => document.getElementById('ps-panel').innerText);
    assert.match(panel, /otopilot belum aktif/);
  });

  await browser.close();
  [host, host4, host5].forEach((h) => h.server.close());
  console.log(failed ? '\n' + failed + ' TES HP GAGAL' : '\nSEMUA TES HP LULUS');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('GAGAL:', e); process.exit(1); });
