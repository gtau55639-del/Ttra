'use strict';
/*
 * Tes Cloudflare Worker (remote-store-worker.mjs) dengan KV tiruan, DAN tes ujung-ke-ujung:
 * add-on sungguhan mengunggah/mengunduh lewat Worker ini (lewat adaptor HTTP kecil).
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const createSync = require('../server/sync-addon');

const TOKEN_W = 'token-worker-123456';
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'wk-'));

(async () => {
  const { default: worker } = await import('../server/remote-store-worker.mjs');
  const kv = new Map();
  const env = {
    TOKEN: TOKEN_W,
    STORE: {
      get: async (k, type) => { const v = kv.get(k); if (!v) return null; assert.equal(type, 'arrayBuffer'); return v.slice(0); },
      put: async (k, v) => { assert.ok(v instanceof ArrayBuffer); kv.set(k, v.slice(0)); },
    },
  };
  const call = (method, headers, body) => worker.fetch(new Request('https://w.example/', { method, headers, body }), env);
  const A = { Authorization: 'Bearer ' + TOKEN_W };

  // --- kontrak Worker
  assert.equal((await call('GET', {})).status, 401);
  assert.equal((await call('GET', { Authorization: 'Bearer salah-salah-salah' })).status, 401);
  assert.equal((await call('GET', A)).status, 404);
  assert.equal((await call('PUT', A, new Uint8Array(0))).status, 400);
  assert.equal((await call('PUT', A, Buffer.from('halo'))).status, 200);
  const g = await call('GET', A);
  assert.equal(g.status, 200); assert.equal(Buffer.from(await g.arrayBuffer()).toString(), 'halo');
  assert.equal((await call('DELETE', A)).status, 405);
  assert.equal((await worker.fetch(new Request('https://w/', { headers: A }), { ...env, TOKEN: 'pendek' })).status, 500);
  const big = await call('PUT', { ...A, 'Content-Length': String(30 * 1024 * 1024) }, Buffer.from('x'));
  assert.ok([413, 400].includes(big.status));
  console.log('ok W1 kontrak Worker: auth, 404, simpan/ambil, batas ukuran, token pendek ditolak');
  kv.clear();

  // --- adaptor: server HTTP lokal yang meneruskan ke worker.fetch (meniru Cloudflare)
  const edge = http.createServer((req, res) => {
    const ch = []; req.on('data', (c) => ch.push(c));
    req.on('end', async () => {
      const body = ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(ch);
      const r = await worker.fetch(new Request('http://edge.local' + req.url, { method: req.method, headers: req.headers, body }), env);
      res.statusCode = r.status; r.headers.forEach((v, k) => res.setHeader(k, v));
      res.end(Buffer.from(await r.arrayBuffer()));
    });
  });
  await new Promise((r) => edge.listen(0, '127.0.0.1', r));
  const storeUrl = 'http://127.0.0.1:' + edge.address().port + '/';

  // --- server 1 mencadangkan lewat Worker
  const d1 = tmp();
  const mk = (dir, extra) => createSync({
    dataDir: dir, adminToken: 'token-rahasia-123456', remoteUrl: storeUrl, remoteToken: TOKEN_W,
    log: () => {}, recoverBackoffMs: [10, 10], localUrl: 'http://127.0.0.1:1', ...extra,
  });
  fs.writeFileSync(path.join(d1, 'projects.json'), '{"projects":[{"projectId":"p1"}]}');
  fs.mkdirSync(path.join(d1, 'projects/p1/session'), { recursive: true });
  fs.writeFileSync(path.join(d1, 'projects/p1/session/creds.json'), '{"noiseKey":"sesi-lewat-worker"}');
  const s1 = mk(d1);
  await s1.recover();
  assert.equal(s1.state().recovery, 'no-remote-snapshot');
  const up = await s1.backupRemote();
  assert.ok(up.ok, JSON.stringify(up));
  assert.ok(kv.size === 1);
  console.log('ok W2 add-on mengunggah ke Worker (' + up.files + ' file, ' + up.bytes + ' byte)');

  // --- disk server hilang: server 2 pulih lewat Worker
  const d2 = tmp();
  const s2 = mk(d2);
  await s2.recover();
  assert.equal(s2.state().recovery, 'restored');
  assert.equal(fs.readFileSync(path.join(d2, 'projects/p1/session/creds.json'), 'utf8'), '{"noiseKey":"sesi-lewat-worker"}');
  assert.equal(s2.readMarker(), s1.readMarker());
  console.log('ok W3 server baru (disk kosong) pulih dari Worker, sesi + marker sama');

  // --- token Worker salah -> pemulihan gagal & tidak menimpa
  const before = Buffer.from(kv.values().next().value);
  const s3 = mk(tmp(), { remoteToken: 'token-salah-salah' });
  await s3.recover();
  assert.equal(s3.state().recovery, 'failed');
  assert.equal((await s3.backupRemote()).skipped, 'not-allowed');
  assert.ok(Buffer.from(kv.values().next().value).equals(before));
  console.log('ok W4 token salah -> gagal jelas, cadangan di KV tidak tersentuh');

  edge.close();
  console.log('\nSEMUA TES WORKER LULUS');
  process.exit(0);
})().catch((e) => { console.error('GAGAL:', e); process.exit(1); });
