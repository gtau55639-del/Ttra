'use strict';
// Menjalankan semua tes berurutan: node tests/run-all.js
const { spawnSync } = require('child_process');
const path = require('path');
const files = ['test-addon.js', 'test-autopilot.js', 'test-worker.js', 'test-phone.js'];
let bad = 0;
for (const f of files) {
  console.log('\n=== ' + f + ' ===');
  const r = spawnSync(process.execPath, [path.join(__dirname, f)], { stdio: 'inherit' });
  if (r.status !== 0) { bad++; console.log('>>> ' + f + ' GAGAL (kode ' + r.status + ')'); }
}
console.log(bad ? '\n' + bad + ' berkas tes GAGAL' : '\nSEMUA BERKAS TES LULUS');
process.exit(bad ? 1 : 0);
