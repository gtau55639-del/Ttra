'use strict';
/*
 * Tes otopilot: server pulih sendiri dari penyimpanan luar dan menyalakan lagi bot, tanpa HP.
 * Memakai server "host" tiruan (API /api/projects seperti yang dipakai app) dan penyimpanan luar tiruan.
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const zlib = require('zlib');
const { spawn } = require('child_process');
const createSync = require('../server/sync-addon');

const TOKEN = 'token-rahasia-123456';
const STORE_TOKEN = 'kunci-penyimpanan-luar-xyz';
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'ap-'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const json = (res, obj, code) => { res.statusCode = code || 200; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(obj)); };
const listen = (srv) => new Promise((r) => srv.listen(0, '127.0.0.1', () => r('http://127.0.0.1:' + srv.address().port)));
const w = (dir, p, c) => { const f = path.join(dir, p); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, c); };

// ---- penyimpanan luar tiruan (PUT/GET + Bearer)
async function makeStore() {
  const st = { data: null, puts: 0, gets: 0, failGet: 0 };
  st.server = http.createServer((req, res) => {
    if ((req.headers.authorization || '') !== 'Bearer ' + STORE_TOKEN) { res.statusCode = 401; return res.end(); }
    if (req.method === 'GET') {
      st.gets++;
      if (st.failGet > 0) { st.failGet--; res.statusCode = 500; return res.end(); }
      if (!st.data) { res.statusCode = 404; return res.end(); }
      res.setHeader('Content-Type', 'application/gzip'); return res.end(st.data);
    }
    if (req.method === 'PUT') {
      const ch = []; req.on('data', (c) => ch.push(c));
      req.on('end', () => { st.puts++; st.data = Buffer.concat(ch); res.end('ok'); });
      return;
    }
    res.statusCode = 405; res.end();
  });
  st.url = (await listen(st.server)) + '/snapshot';
  return st;
}

// ---- server "host" tiruan + add-on
async function makeNode(o) {
  const node = { projects: o.projects || [], calls: [], failStart: new Set(), dir: o.dir || tmp() };
  node.server = http.createServer(async (req, res) => {
    if (node.sync && (await node.sync.handle(req, res))) return;
    const u = new URL(req.url, 'http://x');
    if ((req.headers.authorization || '') !== 'Bearer ' + TOKEN) return json(res, { error: 'auth' }, 401);
    if (req.method === 'GET' && u.pathname === '/api/projects') {
      if (node.listFail) return json(res, { error: 'down' }, 503);
      return json(res, { projects: node.projects });
    }
    const m = /^\/api\/projects\/([^/]+)\/(install|start)$/.exec(u.pathname);
    if (req.method === 'POST' && m) {
      node.calls.push(m[2] + ':' + m[1]);
      if (m[2] === 'start' && node.failStart.has(m[1])) return json(res, { error: 'boom' }, 500);
      const p = node.projects.find((x) => x.projectId === m[1]);
      if (!p) return json(res, { error: 'tidak ada' }, 404);
      if (m[2] === 'start') p.runtimeStatus = 'online';
      return json(res, { ok: true });
    }
    res.statusCode = 404; res.end('host');
  });
  node.url = await listen(node.server);
  node.sync = createSync({
    dataDir: node.dir, adminToken: TOKEN, localUrl: node.url,
    remoteUrl: o.remoteUrl, remoteToken: STORE_TOKEN,
    onImported: async () => { // seperti server asli: baca ulang data dari disk ke memori
      try {
        const j = JSON.parse(fs.readFileSync(path.join(node.dir, 'projects.json'), 'utf8'));
        node.projects = j.projects.map((p) => ({ ...p, runtimeStatus: 'offline' }));
      } catch { /* belum ada */ }
    },
    tickMs: 60000, bootStartDelayMs: 5, healthPollMs: 10, recoverBackoffMs: [10, 10],
    log: () => {}, ...(o.sync || {}),
  });
  node.close = () => { node.sync.stop(); node.server.close(); };
  return node;
}
const tree = (dir) => {
  const out = {};
  (function rec(d, rel) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const abs = path.join(d, e.name), r = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) rec(abs, r); else if (e.isFile() && !/\.sync-tmp-/.test(e.name)) out[r] = fs.readFileSync(abs, 'utf8');
    }
  })(dir, '');
  return out;
};

(async () => {
  const store = await makeStore();

  // ===== A. siklus penuh: cadangkan -> disk hilang -> pulih sendiri -> bot menyala lagi
  const n1 = await makeNode({ remoteUrl: store.url, projects: [{ projectId: 'p1', name: 'Bot Satu', runtimeStatus: 'online' }, { projectId: 'p2', name: 'Bot Dua', runtimeStatus: 'offline' }] });
  w(n1.dir, 'projects.json', JSON.stringify({ projects: [{ projectId: 'p1', name: 'Bot Satu' }, { projectId: 'p2', name: 'Bot Dua' }] }));
  w(n1.dir, 'projects/p1/workspace/index.js', 'console.log("bot satu")');
  w(n1.dir, 'projects/p1/workspace/session/creds.json', '{"noiseKey":"rahasia-sesi"}');
  assert.equal(n1.sync.state().recovery, 'pending');
  assert.equal(n1.sync.state().uploadAllowed, false, 'disk baru: dilarang mengunggah sebelum pemulihan');
  assert.equal((await n1.sync.backupRemote()).skipped, 'not-allowed');
  assert.equal(store.puts, 0);
  await n1.sync.recover();                       // penyimpanan luar masih kosong (404)
  assert.equal(n1.sync.state().recovery, 'no-remote-snapshot');
  await n1.sync.restartBots();                   // belum ada catatan bot -> tidak ada yang dinyalakan
  assert.deepEqual(n1.calls, []);
  await n1.sync.tick();                          // catat bot yang jalan + unggah
  assert.equal(store.puts, 1);
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(n1.dir, '.sync-running.json'), 'utf8')).ids, ['p1']);
  assert.ok(n1.sync.state().lastUpload && n1.sync.state().lastUpload.files >= 4);
  const marker1 = n1.sync.readMarker();
  const before = tree(n1.dir);
  console.log('ok A1 cadangan otomatis ke penyimpanan luar, catatan bot jalan = [p1]');

  // tick kedua tanpa perubahan -> tidak mengunggah lagi (hemat kuota tulis)
  await n1.sync.tick();
  assert.equal(store.puts, 1);
  console.log('ok A2 tidak ada perubahan -> tidak unggah ulang');
  n1.close();

  // --- server direstart dengan DISK KOSONG (Render free tidur/redeploy)
  const n2 = await makeNode({ remoteUrl: store.url });
  assert.notEqual(n2.sync.readMarker(), marker1);
  assert.equal(n2.projects.length, 0);
  await n2.sync.recover();
  assert.equal(n2.sync.state().recovery, 'restored');
  assert.equal(n2.sync.readMarker(), marker1, 'marker ikut pulih');
  const after = tree(n2.dir);
  for (const k of Object.keys(before)) assert.equal(after[k], before[k], 'beda: ' + k);
  assert.equal(n2.projects.length, 2, 'onImported memuat ulang data');
  console.log('ok A3 disk kosong -> data & sesi pulih dari penyimpanan luar tanpa HP');
  await n2.sync.restartBots();
  assert.deepEqual(n2.calls, ['install:p1', 'start:p1'], 'hanya bot yang tadinya jalan');
  assert.equal(n2.projects.find((p) => p.projectId === 'p1').runtimeStatus, 'online');
  assert.equal(n2.sync.state().botsStarted, 1);
  console.log('ok A4 bot yang tadinya jalan menyala lagi (install + start), yang mati dibiarkan');

  // catatan bot tidak boleh terhapus oleh siklus pertama pasca-boot
  n2.projects.find((p) => p.projectId === 'p1').runtimeStatus = 'offline'; // misal sempat belum nyala saat tick
  n2.listFail = true;
  await n2.sync.tick();
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(n2.dir, '.sync-running.json'), 'utf8')).ids, ['p1'], 'gagal baca daftar proyek -> catatan lama dipertahankan');
  n2.listFail = false;
  console.log('ok A5 daftar proyek gagal dibaca -> catatan bot tidak ditimpa kosong');
  n2.close();

  // ===== B. penyimpanan luar error saat boot: JANGAN menimpa cadangan bagus dengan disk kosong
  const putsBefore = store.puts, snapBefore = Buffer.from(store.data);
  store.failGet = 100;
  const n3 = await makeNode({ remoteUrl: store.url });
  await n3.sync.recover();
  assert.equal(n3.sync.state().recovery, 'failed');
  assert.equal(n3.sync.state().uploadAllowed, false);
  assert.equal((await n3.sync.backupRemote()).skipped, 'not-allowed');
  await n3.sync.tick();                          // masih error -> tetap gagal, tetap tidak unggah
  assert.equal(store.puts, putsBefore);
  assert.ok(snapBefore.equals(store.data), 'cadangan di luar tidak boleh berubah');
  console.log('ok B1 penyimpanan luar error -> unggahan ditahan, cadangan lama aman');
  store.failGet = 0;                             // penyimpanan pulih
  await n3.sync.tick();                          // siklus berikutnya: pulih + nyalakan bot
  assert.equal(n3.sync.state().recovery, 'restored');
  assert.deepEqual(n3.calls, ['install:p1', 'start:p1']);
  console.log('ok B2 siklus berikutnya berhasil pulih sendiri + bot menyala');
  n3.close();

  // ===== C. proses restart tapi disk utuh (marker ada): catatan bot tetap menyalakan bot
  const n4 = await makeNode({ remoteUrl: store.url, dir: n3.dir, projects: [{ projectId: 'p1', name: 'Bot Satu', runtimeStatus: 'offline' }] });
  await n4.sync.recover();
  assert.equal(n4.sync.state().recovery, 'intact-disk');
  assert.equal(n4.sync.state().uploadAllowed, true);
  await n4.sync.restartBots();
  assert.deepEqual(n4.calls, ['install:p1', 'start:p1']);
  console.log('ok C  disk utuh tapi proses restart -> bot tetap dinyalakan lagi');
  // bot yang sudah online tidak disentuh
  const n4b = await makeNode({ remoteUrl: store.url, dir: n3.dir, projects: [{ projectId: 'p1', name: 'x', runtimeStatus: 'online' }] });
  await n4b.sync.recover(); await n4b.sync.restartBots();
  assert.deepEqual(n4b.calls, [], 'sudah online -> jangan install/start ulang');
  console.log('ok C2 bot yang sudah online tidak di-start dua kali');
  n4.close(); n4b.close();

  // ===== D. bot gagal start -> dicoba lagi di siklus berikutnya, lalu berhasil
  const n5 = await makeNode({ remoteUrl: store.url, dir: n3.dir, projects: [{ projectId: 'p1', name: 'x', runtimeStatus: 'offline' }] });
  n5.failStart.add('p1');
  await n5.sync.recover(); await n5.sync.restartBots();
  assert.equal(n5.sync.state().botsStarted, 0);
  await n5.sync.tick();                          // percobaan ulang (masih gagal) -> catatan dipertahankan
  assert.deepEqual(JSON.parse(fs.readFileSync(path.join(n5.dir, '.sync-running.json'), 'utf8')).ids, ['p1']);
  n5.failStart.delete('p1');
  await n5.sync.tick();
  assert.equal(n5.projects[0].runtimeStatus, 'online');
  assert.equal(n5.sync.state().botsStarted, 1);
  console.log('ok D  bot gagal start -> dicoba ulang otomatis sampai berhasil');
  n5.close();

  // ===== E. pengaman penyusutan: data tiba-tiba sedikit -> unggahan ditahan sampai bertahan 3 siklus
  const n6 = await makeNode({ remoteUrl: store.url });
  for (let i = 0; i < 12; i++) w(n6.dir, 'data/f' + i + '.json', '{"i":' + i + '}');
  await n6.sync.recover();                       // 404? tidak: store sudah berisi -> restored (menimpa/menambah)
  await n6.sync.backupRemote({ force: true });
  const ok1 = store.puts;
  fs.rmSync(path.join(n6.dir, 'data'), { recursive: true }); fs.rmSync(path.join(n6.dir, 'projects'), { recursive: true, force: true });
  fs.rmSync(path.join(n6.dir, 'projects.json'), { force: true });
  assert.equal((await n6.sync.backupRemote()).skipped, 'shrink');
  assert.equal((await n6.sync.backupRemote()).skipped, 'shrink');
  assert.equal(store.puts, ok1, 'ditahan 2 kali');
  assert.ok((await n6.sync.backupRemote()).ok, 'ke-3: dianggap sengaja -> diunggah');
  console.log('ok E  pengaman penyusutan: tahan 2 siklus, lalu terima kalau memang disengaja');
  n6.close();

  // ===== F. cadangan terlalu besar -> tidak diunggah, alasan tercatat
  const store2 = await makeStore();
  const n7 = await makeNode({ remoteUrl: store2.url, sync: { remoteMaxBytes: 500 } });
  w(n7.dir, 'a.json', JSON.stringify({ x: require('crypto').randomBytes(2000).toString('hex') }));
  await n7.sync.recover();
  const rr = await n7.sync.backupRemote();
  assert.ok(rr.error && /remoteMaxBytes/.test(rr.error));
  assert.equal(store2.puts, 0);
  assert.match(n7.sync.state().lastError, /remoteMaxBytes/);
  console.log('ok F  melebihi batas -> tidak diunggah, alasan terlihat di status');
  n7.close(); store2.server.close();

  // ===== G. token penyimpanan salah -> pemulihan gagal, TIDAK menimpa
  const badStore = await makeStore();
  const n8 = await makeNode({ remoteUrl: badStore.url, sync: { remoteToken: 'salah' } });
  await n8.sync.recover();
  assert.equal(n8.sync.state().recovery, 'failed');
  assert.match(n8.sync.state().lastError, /401/);
  assert.equal(badStore.puts, 0);
  console.log('ok G  token penyimpanan salah -> status gagal yang jelas (401), tidak ada unggahan');
  n8.close(); badStore.server.close();

  // ===== H. status endpoint menampilkan otopilot
  const n9 = await makeNode({ remoteUrl: store.url });
  await n9.sync.recover();
  const st = await (await fetch(n9.url + '/api/sync/status', { headers: { Authorization: 'Bearer ' + TOKEN } })).json();
  assert.equal(st.autopilot.remote, true); assert.equal(st.autopilot.recovery, 'restored');
  assert.ok(!JSON.stringify(st).includes(STORE_TOKEN), 'token penyimpanan tidak boleh bocor');
  console.log('ok H  /api/sync/status menampilkan status otopilot tanpa membocorkan token');
  n9.close();

  // ===== I. SIGTERM: cadangan terakhir sebelum mati, dan tidak menghalangi handler milik host
  for (const hostHandler of [false, true]) {
    const st3 = await makeStore();
    const dir = tmp();
    const child = spawn(process.execPath, ['-e', `
      const fs=require('fs'),path=require('path');
      const createSync=require(${JSON.stringify(path.resolve(__dirname, '../server/sync-addon'))});
      const s=createSync({dataDir:${JSON.stringify(dir)},adminToken:'${TOKEN}',remoteUrl:${JSON.stringify(st3.url)},remoteToken:'${STORE_TOKEN}',
        localUrl:'http://127.0.0.1:1',tickMs:600000,bootStartDelayMs:1,healthPollMs:10,healthTimeoutMs:50,log:()=>{}});
      s.start();
      ${hostHandler ? "process.on('SIGTERM', ()=>{ setTimeout(()=>{ fs.writeFileSync(path.join(" + JSON.stringify(dir) + ",'host-selesai'),'1'); process.exit(0); }, 400); });" : ''}
      setTimeout(()=>{ fs.writeFileSync(path.join(${JSON.stringify(dir)},'catatan-terakhir.json'),'{"ok":true}'); console.log('SIAP'); }, 700);
      setInterval(()=>{}, 1000);
    `], { stdio: ['ignore', 'pipe', 'inherit'] });
    await new Promise((res) => child.stdout.on('data', (d) => { if (String(d).includes('SIAP')) res(); }));
    child.kill('SIGTERM');
    const code = await new Promise((res) => child.on('exit', (c) => res(c)));
    assert.equal(code, 0, 'harus keluar normal');
    assert.ok(st3.puts >= 1, 'harus ada unggahan terakhir saat SIGTERM');
    const lines = zlib.gunzipSync(st3.data).toString().split('\n').filter(Boolean).map((l) => JSON.parse(l));
    const names = lines.filter((l) => l.p).map((l) => l.p);
    assert.ok(names.includes('catatan-terakhir.json'), 'file terakhir harus ikut cadangan: ' + names);
    if (hostHandler) assert.ok(fs.existsSync(path.join(dir, 'host-selesai')), 'handler SIGTERM milik host tidak boleh dipotong');
    st3.server.close();
  }
  console.log('ok I  SIGTERM -> cadangan terakhir terunggah; handler milik host tetap jalan; tanpa handler host proses tetap keluar');

  store.server.close();
  console.log('\nSEMUA TES OTOPILOT LULUS');
  process.exit(0);
})().catch((e) => { console.error('GAGAL:', e); process.exit(1); });
