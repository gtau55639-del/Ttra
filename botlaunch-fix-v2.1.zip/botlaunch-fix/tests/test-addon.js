'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const zlib = require('zlib');
const crypto = require('crypto');
const createSync = require('../server/sync-addon');

const TOKEN = 'token-rahasia-123456';
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'sync-'));
const H = { Authorization: 'Bearer ' + TOKEN };

function tree(dir) {
  const out = {};
  (function rec(d, rel) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const abs = path.join(d, e.name), r = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) rec(abs, r);
      else if (e.isFile()) out[r] = crypto.createHash('sha1').update(fs.readFileSync(abs)).digest('hex');
    }
  })(dir, '');
  return out;
}
function parseV2(gz) {
  const ls = zlib.gunzipSync(gz).toString('utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
  return { header: ls[0], files: ls.slice(1, -1), end: ls[ls.length - 1] };
}
function serve(sync) {
  return new Promise((res) => {
    const s = http.createServer(async (req, rs) => {
      if (await sync.handle(req, rs)) return;
      rs.statusCode = 404; rs.end('host');
    }).listen(0, '127.0.0.1', () => res({ s, url: 'http://127.0.0.1:' + s.address().port }));
  });
}

(async () => {
  // ---- siapkan data sumber
  const A = tmp();
  const w = (p, c) => { const f = path.join(A, p); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, c); };
  w('projects.json', JSON.stringify({ projects: [{ projectId: 'p1' }] }));
  w('projects/p1/workspace/index.js', 'console.log("bot")');
  w('projects/p1/workspace/session/creds.json', '{"noiseKey":"abc"}');
  w('projects/p1/workspace/node_modules/x/index.js', 'junk');
  w('projects/p1/bot.log', 'log panjang');
  w('projects/p1/besar.bin', 'x'.repeat(3000));
  fs.symlinkSync('/etc', path.join(A, 'link-ke-etc'));

  let reloaded = null;
  const syncA = createSync({ dataDir: A, adminToken: TOKEN, maxFileBytes: 2000, onImported: async (i) => { reloaded = i; }, log: () => {} });
  const a = await serve(syncA);

  // 1. health tanpa login + HEAD
  let r = await fetch(a.url + '/api/health');
  let j = await r.json();
  assert.equal(r.status, 200); assert.equal(j.ok, true); assert.equal(j.sync, true); assert.ok(j.bootId);
  assert.equal((await fetch(a.url + '/api/health', { method: 'HEAD' })).status, 200);
  console.log('ok 1 health');

  // 2. auth
  assert.equal((await fetch(a.url + '/api/sync/status')).status, 401);
  assert.equal((await fetch(a.url + '/api/sync/status', { headers: { Authorization: 'Bearer salah' } })).status, 401);
  r = await fetch(a.url + '/api/sync/status', { headers: H }); j = await r.json();
  assert.equal(r.status, 200); assert.ok(j.marker); assert.ok(j.files >= 4);
  const markerA = j.marker;
  console.log('ok 2 auth + status');

  // 3. CORS preflight
  r = await fetch(a.url + '/api/sync/export', { method: 'OPTIONS', headers: { Origin: 'https://localhost', 'Access-Control-Request-Headers': 'authorization' } });
  assert.equal(r.status, 204); assert.equal(r.headers.get('access-control-allow-origin'), '*');
  assert.match(r.headers.get('access-control-allow-headers'), /Authorization/i);
  console.log('ok 3 CORS');

  // 4. export: node_modules, .log, symlink, file besar tidak ikut
  r = await fetch(a.url + '/api/sync/export', { headers: H });
  assert.equal(r.status, 200);
  const gz = Buffer.from(await r.arrayBuffer());
  const snap = parseV2(gz);
  assert.equal(snap.header.v, 2);
  const names = snap.files.map((f) => f.p).sort();
  assert.deepEqual(names, ['.sync-marker', 'projects.json', 'projects/p1/workspace/index.js', 'projects/p1/workspace/session/creds.json']);
  assert.deepEqual(snap.end.skipped, ['projects/p1/besar.bin']);
  assert.equal(r.headers.get('x-sync-marker'), markerA);
  assert.equal(r.headers.get('x-sync-files'), '4');
  console.log('ok 4 export', names.length, 'file');

  // 5. import ke server kosong (simulasi disk ke-reset) -> pohon sama + marker ikut pulih
  const B = tmp();
  let reloadedB = null;
  const syncB = createSync({ dataDir: B, adminToken: TOKEN, onImported: async (i) => { reloadedB = i; }, log: () => {} });
  const b = await serve(syncB);
  const markerBefore = (await (await fetch(b.url + '/api/sync/status', { headers: H })).json()).marker;
  assert.notEqual(markerBefore, markerA);
  r = await fetch(b.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: gz });
  j = await r.json();
  assert.equal(r.status, 200); assert.equal(j.files, 4); assert.equal(j.reload, 'ok'); assert.equal(j.rejected.length, 0);
  assert.equal(reloadedB.files, 4);
  const markerAfter = (await (await fetch(b.url + '/api/sync/status', { headers: H })).json()).marker;
  assert.equal(markerAfter, markerA);
  const tA = tree(A), tB = tree(B);
  for (const k of names) assert.equal(tB[k], tA[k], 'beda: ' + k);
  assert.ok(!tB['projects/p1/workspace/node_modules/x/index.js']);
  console.log('ok 5 import + marker pulih + hook onImported');

  // 6. path traversal ditolak
  const evil = zlib.gzipSync(JSON.stringify({ v: 1, files: [
    { p: '../evil.txt', m: 420, d: Buffer.from('x').toString('base64') },
    { p: '/abs.txt', m: 420, d: 'eA==' },
    { p: 'a/../../b.txt', m: 420, d: 'eA==' },
    { p: 'c\\d.txt', m: 420, d: 'eA==' },
    { p: 'proj/node_modules/z.js', m: 420, d: 'eA==' },
    { p: 'ok/aman.txt', m: 0o4755, d: Buffer.from('aman').toString('base64') },
  ] }));
  r = await fetch(b.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: evil });
  j = await r.json();
  assert.equal(j.files, 1); assert.equal(j.rejected.length, 5);
  assert.ok(!fs.existsSync(path.join(path.dirname(B), 'evil.txt')));
  assert.ok(!fs.existsSync(path.join(path.dirname(B), 'b.txt')));
  assert.equal(fs.statSync(path.join(B, 'ok/aman.txt')).mode & 0o7000, 0); // tidak ada setuid
  console.log('ok 6 traversal ditolak, setuid dibuang');

  // 7. snapshot rusak / terlalu besar
  r = await fetch(b.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: Buffer.from('bukan gzip') });
  assert.equal(r.status, 400);
  const syncSmall = createSync({ dataDir: tmp(), adminToken: TOKEN, maxTotalBytes: 1000, log: () => {} });
  const sm = await serve(syncSmall);
  r = await fetch(sm.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: Buffer.alloc(10 * 1024 * 1024, 1) });
  assert.equal(r.status, 413);
  console.log('ok 7 rusak=400, kebesaran=413');

  // 8. tanpa ADMIN_TOKEN: health jalan, sync ditolak 403
  const syncNT = createSync({ dataDir: tmp(), adminToken: '', log: () => {} });
  const nt = await serve(syncNT);
  assert.equal((await fetch(nt.url + '/api/health')).status, 200);
  assert.equal((await fetch(nt.url + '/api/sync/export', { headers: H })).status, 403);
  console.log('ok 8 tanpa ADMIN_TOKEN -> 403');

  // 9. request lain diteruskan ke server host
  r = await fetch(a.url + '/api/projects');
  assert.equal(await r.text(), 'host');
  console.log('ok 9 route lain tidak dicegat');

  // 10. middleware gaya Express
  await new Promise((res) => {
    const s = http.createServer((req, rs) => syncA.middleware(req, rs, () => { rs.statusCode = 418; rs.end(); })).listen(0, '127.0.0.1', async () => {
      const u = 'http://127.0.0.1:' + s.address().port;
      assert.equal((await fetch(u + '/api/health')).status, 200);
      assert.equal((await fetch(u + '/lain')).status, 418);
      s.close(); res();
    });
  });
  console.log('ok 10 middleware next()');

  // 11. format lama (v1, satu JSON besar) tetap bisa dipulihkan -> cadangan lama di HP tidak hangus
  {
    const D = tmp();
    const sy = createSync({ dataDir: D, adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    const v1 = zlib.gzipSync(JSON.stringify({ v: 1, marker: 'm1', files: [
      { p: 'projects.json', m: 420, d: Buffer.from('{"projects":[]}').toString('base64') },
      { p: '.sync-marker', m: 420, d: Buffer.from('{"id":"lama123"}').toString('base64') },
    ] }));
    const rr = await fetch(sv.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: v1 });
    const jj = await rr.json();
    assert.equal(rr.status, 200); assert.equal(jj.files, 2); assert.equal(jj.marker, 'lama123');
    sv.s.close();
    console.log('ok 11 snapshot v1 lama tetap bisa diimpor');
  }

  // 12. snapshot terpotong -> ditolak 400, TIDAK ada file/marker yang berubah (atomik)
  {
    const D = tmp();
    const sy = createSync({ dataDir: D, adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    const markerBeforeT = sy.readMarker();
    const cut = gz.subarray(0, Math.floor(gz.length * 0.6));
    const rr = await fetch(sv.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: cut });
    assert.equal(rr.status, 400);
    assert.equal(sy.readMarker(), markerBeforeT, 'marker tidak boleh berubah');
    assert.ok(!fs.existsSync(path.join(D, 'projects.json')), 'tidak boleh ada file setengah jadi');
    assert.deepEqual(fs.readdirSync(D).sort(), ['.sync-marker']);
    // v2 utuh tapi tanpa baris "end" juga ditolak
    const noEnd = zlib.gzipSync(JSON.stringify({ v: 2, marker: 'x' }) + '\n' + JSON.stringify({ p: 'a.txt', m: 420, d: 'eA==' }) + '\n');
    const r2 = await fetch(sv.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: noEnd });
    assert.equal(r2.status, 400);
    assert.ok(!fs.existsSync(path.join(D, 'a.txt')));
    sv.s.close();
    console.log('ok 12 snapshot terpotong ditolak, tidak ada yang berubah');
  }

  // 13. file JSON yang sedang ditulis bot (terpotong) ditunggu sampai valid, bukan ikut rusak
  {
    const D = tmp();
    fs.writeFileSync(path.join(D, 'creds.json'), '{"noiseKey":"abc');
    setTimeout(() => fs.writeFileSync(path.join(D, 'creds.json'), '{"noiseKey":"abc-lengkap"}'), 90);
    const sy = createSync({ dataDir: D, adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    const rr = await fetch(sv.url + '/api/sync/export', { headers: H });
    const got = parseV2(Buffer.from(await rr.arrayBuffer())).files.find((f) => f.p === 'creds.json');
    assert.equal(Buffer.from(got.d, 'base64').toString(), '{"noiseKey":"abc-lengkap"}');
    sv.s.close();
    console.log('ok 13 file JSON setengah tertulis tidak ikut rusak');
  }

  // 14. token pendek ditolak (README: minimal 12 karakter)
  {
    const sy = createSync({ dataDir: tmp(), adminToken: 'abc', log: () => {} });
    const sv = await serve(sy);
    const rr = await fetch(sv.url + '/api/sync/status', { headers: { Authorization: 'Bearer abc' } });
    assert.equal(rr.status, 403);
    assert.equal((await fetch(sv.url + '/api/health')).status, 200);
    sv.s.close();
    console.log('ok 14 token < 12 karakter ditolak');
  }

  // 15. URL aneh tidak boleh menjatuhkan server (dulu: unhandled rejection -> crash)
  {
    let crashed = null;
    const onRej = (e) => { crashed = e; };
    process.on('unhandledRejection', onRej);
    const sy = createSync({ dataDir: tmp(), adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    const port = new URL(sv.url).port;
    await new Promise((res) => {
      const q = http.request({ host: '127.0.0.1', port, path: '//[', timeout: 1500 }, (x) => { x.resume(); x.on('end', res); });
      q.on('timeout', () => { q.destroy(); res(); }); q.on('error', () => res()); q.end();
    });
    await new Promise((r) => setTimeout(r, 100));
    process.off('unhandledRejection', onRej);
    assert.equal(crashed, null, 'tidak boleh ada unhandled rejection');
    assert.equal((await fetch(sv.url + '/api/health')).status, 200);
    sv.s.close();
    console.log('ok 15 URL aneh tidak membuat server jatuh');
  }

  // 16. ekspor di-stream: lonjakan memori jauh di bawah ukuran data (dulu +173 MB untuk 36 MB)
  {
    const D = tmp();
    for (let i = 0; i < 4; i++) fs.writeFileSync(path.join(D, 'f' + i + '.bin'), crypto.randomBytes(9 * 1024 * 1024));
    const sy = createSync({ dataDir: D, adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    if (global.gc) global.gc();
    const base = process.memoryUsage().rss; let peak = base;
    const iv = setInterval(() => { peak = Math.max(peak, process.memoryUsage().rss); }, 5);
    const rr = await fetch(sv.url + '/api/sync/export', { headers: H });
    // konsumsi sambil lalu, tanpa menyimpan semuanya di sisi klien
    let got = 0; for await (const c of rr.body) got += c.length;
    clearInterval(iv);
    const spike = Math.round((peak - base) / 1048576);
    assert.ok(got > 30 * 1024 * 1024, 'data harus terkirim lengkap');
    assert.ok(spike < 110, 'lonjakan memori terlalu besar: +' + spike + ' MB');
    sv.s.close();
    console.log('ok 16 ekspor 36 MB: lonjakan RSS +' + spike + ' MB (server + klien dalam satu proses)');
  }

  // 17. dua operasi berat bersamaan -> yang kedua 429, bukan balapan
  {
    const D = tmp();
    fs.writeFileSync(path.join(D, 'big.bin'), crypto.randomBytes(8 * 1024 * 1024));
    const sy = createSync({ dataDir: D, adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    const [r1, r2] = await Promise.all([
      fetch(sv.url + '/api/sync/export', { headers: H }).then(async (x) => { await x.arrayBuffer(); return x.status; }),
      fetch(sv.url + '/api/sync/export', { headers: H }).then(async (x) => { await x.arrayBuffer(); return x.status; }),
    ]);
    assert.deepEqual([r1, r2].sort(), [200, 429]);
    assert.equal((await fetch(sv.url + '/api/sync/export', { headers: H }).then((x) => x.status)), 200); // kunci terlepas
    sv.s.close();
    console.log('ok 17 kunci operasi: 200 + 429, lalu normal lagi');
  }

  // 18. batas total tercapai: file kecil penting (sesi) didahulukan, file besar yang dibuang
  {
    const D = tmp();
    fs.mkdirSync(path.join(D, 'a-media')); fs.mkdirSync(path.join(D, 'z-session'));
    for (let i = 0; i < 4; i++) fs.writeFileSync(path.join(D, 'a-media', 'm' + i + '.bin'), Buffer.alloc(900));
    fs.writeFileSync(path.join(D, 'z-session', 'creds.json'), '{"k":1}');
    const sy = createSync({ dataDir: D, adminToken: TOKEN, maxTotalBytes: 2700, log: () => {} });
    const sv = await serve(sy);
    const rr = await fetch(sv.url + '/api/sync/export', { headers: H });
    const sn = parseV2(Buffer.from(await rr.arrayBuffer()));
    assert.ok(sn.files.some((f) => f.p === 'z-session/creds.json'), 'creds.json harus ikut');
    assert.equal(sn.end.skipped.length, 2); // 2 media terbesar urutannya yang tergusur
    sv.s.close();
    console.log('ok 18 file kecil penting didahulukan saat batas penuh');
  }

  // 19. symlink di dalam DATA_DIR tidak bisa dipakai menulis keluar folder lewat import
  {
    const D = tmp(), OUT = tmp();
    fs.symlinkSync(OUT, path.join(D, 'keluar'));
    const sy = createSync({ dataDir: D, adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    const evilSym = zlib.gzipSync(JSON.stringify({ v: 1, files: [{ p: 'keluar/pwn.txt', m: 420, d: 'eA==' }] }));
    const rr = await fetch(sv.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body: evilSym });
    const jj = await rr.json();
    assert.equal(jj.files, 0); assert.equal(jj.rejected.length, 1);
    assert.deepEqual(fs.readdirSync(OUT), []);
    sv.s.close();
    console.log('ok 19 symlink keluar folder ditolak');
  }

  // 20. marker dipasang PALING AKHIR (marker cocok = pemulihan benar-benar selesai), walau di snapshot ia di urutan pertama
  {
    const D = tmp();
    const sy = createSync({ dataDir: D, adminToken: TOKEN, log: () => {} });
    const sv = await serve(sy);
    const order = [];
    const realRename = fs.promises.rename;
    fs.promises.rename = async (from, to) => { order.push(path.basename(to)); return realRename(from, to); };
    try {
      const body = zlib.gzipSync([
        JSON.stringify({ v: 2, marker: 'zzz' }),
        JSON.stringify({ p: '.sync-marker', m: 420, d: Buffer.from('{"id":"mk1"}').toString('base64') }),
        JSON.stringify({ p: 'a.txt', m: 420, d: 'eA==' }),
        JSON.stringify({ p: 'b.txt', m: 420, d: 'eA==' }),
        JSON.stringify({ end: true, files: 3, skipped: [] }), '',
      ].join('\n'));
      const rr = await fetch(sv.url + '/api/sync/import', { method: 'POST', headers: { ...H, 'Content-Type': 'application/gzip' }, body });
      assert.equal(rr.status, 200);
    } finally { fs.promises.rename = realRename; }
    assert.equal(order[order.length - 1], '.sync-marker', 'urutan rename: ' + order);
    assert.equal(sy.readMarker(), 'mk1');
    sv.s.close();
    console.log('ok 20 marker dipasang paling akhir');
  }

  [a, b, sm, nt].forEach((x) => x.s.close());
  console.log('\nSEMUA TES ADD-ON LULUS');
})().catch((e) => { console.error('GAGAL:', e); process.exit(1); });
