/*
 * BOTLAUNCH phone-sync - cadangan data di HP + bangunkan server + pulihkan otomatis.
 * Dipasang lewat <script defer src="/phone-sync.js"></script>. Tanpa dependency.
 * Butuh server dengan sync-addon.js (endpoint /api/health dan /api/sync/*).
 */
(function () {
  'use strict';
  if (window.BotlaunchPhoneSync) return;

  var CFG = Object.assign({
    tickMs: 60 * 1000,            // cek server tiap 1 menit (saat app terbuka)
    snapshotMs: 10 * 60 * 1000,   // cadangan baru tiap 10 menit
    wakeTimeoutMs: 75 * 1000,     // server free butuh sampai ~1 menit untuk bangun
    wakeRetries: 3,
    wakeHtmlRetries: 6,           // respons HTML berulang ~1 menit = add-on belum terpasang
    wakeHtmlGapMs: 10 * 1000,
    firstTickMs: 2500,
    actionTimeoutMs: 15 * 60 * 1000,
    autoRestoreGapMs: 5 * 60 * 1000
  }, window.BOTLAUNCH_SYNC || {});

  var LS_SERVER = 'botlaunch.server', LS_TOKEN = 'botlaunch.token';
  var st = { kind: 'idle', text: 'HP: menunggu', detail: '', sticky: false };
  var busy = false, lastAutoRestore = 0, ui = {};

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function server() { try { return (localStorage.getItem(LS_SERVER) || '').replace(/\/+$/, ''); } catch (e) { return ''; } }
  function token() { try { return localStorage.getItem(LS_TOKEN) || sessionStorage.getItem(LS_TOKEN) || ''; } catch (e) { return ''; } }
  function isNative() { try { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) { return false; } }
  function authH(extra) { var h = Object.assign({}, extra); var t = token(); if (t) h.Authorization = 'Bearer ' + t; return h; }
  function api(path, init, ms) {
    var c = new AbortController();
    var t = setTimeout(function () { c.abort(); }, ms || 30000);
    var o = Object.assign({}, init, { signal: c.signal });
    return fetch(server() + '/api' + path, o).finally(function () { clearTimeout(t); });
  }
  function fmtBytes(n) { return n < 1048576 ? Math.max(1, Math.round(n / 1024)) + ' KB' : (n / 1048576).toFixed(1) + ' MB'; }
  function fmtTime(ts) {
    var d = new Date(ts), n = new Date();
    var hm = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    if (d.toDateString() === n.toDateString()) return hm;
    return d.getDate() + '/' + (d.getMonth() + 1) + ' ' + hm; // cadangan kemarin tidak boleh terlihat seperti "baru saja"
  }

  // ---------- penyimpanan di HP (IndexedDB) ----------
  var dbp = null;
  function db() {
    if (!dbp) dbp = new Promise(function (res, rej) {
      var r = indexedDB.open('botlaunch-phone', 1);
      r.onupgradeneeded = function () { r.result.createObjectStore('kv'); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { dbp = null; rej(r.error); };
      r.onblocked = function () { dbp = null; rej(new Error('Penyimpanan HP sedang dipakai proses lain')); };
    });
    return dbp;
  }
  function kvGet(k) {
    return db().then(function (d) {
      return new Promise(function (res, rej) {
        var q = d.transaction('kv').objectStore('kv').get(k);
        q.onsuccess = function () { res(q.result || null); };
        q.onerror = function () { rej(q.error); };
      });
    });
  }
  function kvSet(k, v) {
    return db().then(function (d) {
      return new Promise(function (res, rej) {
        var tx = d.transaction('kv', 'readwrite');
        tx.objectStore('kv').put(v, k);
        tx.oncomplete = function () { res(); };
        tx.onerror = tx.onabort = function () { rej(tx.error || new Error('Penyimpanan HP penuh atau ditolak')); };
      });
    });
  }
  function key(n) { return n + '|' + server(); } // cadangan dipisah per alamat server

  // ---------- status + UI ----------
  // sticky = peringatan yang tidak boleh ditimpa status "OK" otomatis sampai ada aksi baru
  function setState(kind, text, detail, sticky) {
    st = { kind: kind, text: text, detail: detail || '', sticky: !!sticky };
    if (ui.chipText) {
      ui.chip.setAttribute('data-kind', kind);
      ui.chipText.textContent = text;
      ui.detail.textContent = detail || '';
      ui.title.textContent = text;
    }
  }
  // status "sibuk" biasa tidak boleh menghapus peringatan sticky
  function busyText(t) { if (!st.sticky) setState('busy', t); }
  function refreshInfo(snap) {
    if (!ui.info) return;
    ui.info.textContent = snap
      ? 'Cadangan terakhir ' + fmtTime(snap.at) + ' \u00b7 ' + snap.files + ' file \u00b7 ' + fmtBytes(snap.bytes)
      : 'Belum ada cadangan di HP.';
  }
  // Baris info: apakah server sudah punya otopilot (cadangan luar + pulih sendiri tanpa HP)
  function showAutopilot(a) {
    if (!ui.ap) return;
    if (!a || !a.remote) { ui.ap.textContent = 'Server: pemulihan hanya lewat HP (otopilot belum aktif).'; return; }
    var t = 'Server otopilot: ' + (a.recovery === 'failed' ? 'pemulihan gagal' : 'aktif');
    if (a.lastUpload && a.lastUpload.at) t += ' \u00b7 cadangan luar ' + fmtTime(Date.parse(a.lastUpload.at));
    if (a.lastError) t += ' \u00b7 ' + a.lastError;
    ui.ap.textContent = t;
  }
  function markOk(snap) {
    if (st.sticky) { refreshInfo(snap); return; }
    setState('ok', snap ? 'HP \u2713 ' + fmtTime(snap.at) : 'HP \u2713', '');
    refreshInfo(snap);
  }
  function buildUI() {
    var css = document.createElement('style');
    css.textContent =
      '#ps-chip,#ps-panel{position:fixed;left:10px;z-index:2147483000;font:600 12px/1.3 system-ui,-apple-system,sans-serif;color:#e6e9f2;box-sizing:border-box}' +
      '#ps-chip{bottom:calc(env(safe-area-inset-bottom,0px) + 10px);display:flex;align-items:center;gap:7px;max-width:calc(100vw - 20px);padding:7px 12px;border-radius:999px;border:1px solid #2b3550;background:#141a28;box-shadow:0 4px 14px rgba(0,0,0,.4);cursor:pointer}' +
      '#ps-chip i{width:8px;height:8px;border-radius:50%;background:#8a93a8;flex:none}' +
      '#ps-chip[data-kind=ok] i{background:#3ecf8e}#ps-chip[data-kind=busy] i{background:#f5b942;animation:ps-p 1s infinite}' +
      '#ps-chip[data-kind=warn] i{background:#f5b942}#ps-chip[data-kind=bad] i{background:#ff6b6b}' +
      '#ps-chip span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
      '#ps-panel{bottom:calc(env(safe-area-inset-bottom,0px) + 52px);width:min(300px,calc(100vw - 20px));padding:12px;border-radius:14px;border:1px solid #2b3550;background:#141a28;box-shadow:0 8px 24px rgba(0,0,0,.5);display:none}' +
      '#ps-panel.open{display:block}#ps-panel b{display:block;font-size:13px;margin-bottom:4px}' +
      '#ps-panel p{margin:0 0 8px;font-weight:500;color:#aab2c5;word-break:break-word}' +
      '#ps-panel button{width:100%;margin-top:6px;padding:9px;border-radius:9px;border:1px solid #2b3550;background:#1d2538;color:#e6e9f2;font:600 12px system-ui,sans-serif}' +
      '#ps-panel button:disabled{opacity:.5}@keyframes ps-p{50%{opacity:.35}}';
    document.head.appendChild(css);

    ui.chip = document.createElement('button');
    ui.chip.id = 'ps-chip'; ui.chip.type = 'button'; ui.chip.setAttribute('data-kind', 'idle');
    ui.chip.innerHTML = '<i></i><span></span>';
    ui.chipText = ui.chip.querySelector('span');

    ui.panel = document.createElement('div');
    ui.panel.id = 'ps-panel';
    ui.panel.innerHTML = '<b></b><p class="d"></p><p class="i"></p><p class="a"></p>' +
      '<button type="button" data-a="backup">Cadangkan sekarang</button>' +
      '<button type="button" data-a="restore">Pulihkan ke server</button>';
    ui.title = ui.panel.querySelector('b');
    ui.detail = ui.panel.querySelector('.d');
    ui.info = ui.panel.querySelector('.i');
    ui.ap = ui.panel.querySelector('.a');

    ui.chip.addEventListener('click', function () { ui.panel.classList.toggle('open'); });
    ui.panel.addEventListener('click', function (e) {
      var a = e.target && e.target.getAttribute && e.target.getAttribute('data-a');
      if (a === 'backup') backupNow();
      if (a === 'restore') restoreNow();
    });
    document.body.appendChild(ui.panel);
    document.body.appendChild(ui.chip);
    setState(st.kind, st.text, st.detail);
    kvGet(key('snap')).then(refreshInfo).catch(function () {});
  }

  // ---------- bicara dengan server ----------
  // Bangunkan server free yang tertidur: coba beberapa kali dengan timeout panjang.
  async function wake() {
    var html = 0, tries = 0;
    for (;;) { // berakhir lewat return / break di bawah
      tries++;
      var sawHtml = false;
      try {
        var r = await api('/health', { cache: 'no-store' }, CFG.wakeTimeoutMs);
        if (r.status === 404) return { noaddon: true };
        if (r.ok) {
          var ct = (r.headers.get('content-type') || '').toLowerCase();
          if (ct.indexOf('json') >= 0) {
            var j = await r.json();
            return j && j.sync ? { ok: true, health: j } : { noaddon: true };
          }
          sawHtml = true; // halaman loading Render ATAU aplikasi tanpa add-on (SPA mengembalikan index.html)
        }
      } catch (e) { /* timeout / jaringan */ }
      if (sawHtml) {
        html++;
        if (html >= CFG.wakeHtmlRetries) return { noaddon: true };
        busyText('Membangunkan server\u2026 ' + html + '/' + CFG.wakeHtmlRetries);
        await sleep(CFG.wakeHtmlGapMs);
      } else {
        if (tries >= CFG.wakeRetries) break;
        busyText('Membangunkan server\u2026 ' + tries + '/' + CFG.wakeRetries);
        await sleep(2500);
      }
    }
    return { down: true };
  }
  // null = gagal dibaca (jangan dianggap "tidak ada bot")
  async function listProjects() {
    try {
      var r = await api('/projects', { headers: authH(), cache: 'no-store' }, 30000);
      if (!r.ok) return null;
      var j = await r.json();
      return (j && Array.isArray(j.projects)) ? j.projects : null;
    } catch (e) { return null; }
  }
  async function act(id, action) {
    var r = await api('/projects/' + encodeURIComponent(id) + '/' + action, { method: 'POST', headers: authH() }, CFG.actionTimeoutMs);
    if (!r.ok) {
      var j = await r.json().catch(function () { return {}; });
      throw new Error(j.error || (action + ' gagal'));
    }
  }

  async function backup(force) {
    busyText('Mencadangkan ke HP\u2026');
    var r = await api('/sync/export', { headers: authH(), cache: 'no-store' }, 180000);
    if (!r.ok) throw new Error('export ' + r.status);
    var buf = await r.arrayBuffer();
    var files = parseInt(r.headers.get('X-Sync-Files') || '0', 10);
    var old = await kvGet(key('snap'));
    // Pengaman otomatis; tombol "Cadangkan sekarang" (force) sengaja boleh melewatinya, kalau tidak
    // cadangan akan macet selamanya setelah kamu menghapus banyak proyek.
    if (!force && old && old.files >= 5 && files < old.files * 0.3) {
      throw new Error('Data server jauh lebih sedikit dari cadangan lama; tekan "Cadangkan sekarang" kalau memang disengaja');
    }
    // Daftar bot yang sedang jalan. Kalau API gagal / daftar kosong, pakai catatan lama: jangan sampai
    // "bot mana yang harus dinyalakan lagi" terhapus gara-gara satu request gagal.
    var plist = await listProjects();
    var running = (plist && plist.length)
      ? plist.filter(function (p) { return p.runtimeStatus === 'online'; }).map(function (p) { return p.projectId; })
      : ((old && old.running) || []);
    var rec = {
      buf: buf, at: Date.now(), marker: r.headers.get('X-Sync-Marker') || '', files: files,
      bytes: parseInt(r.headers.get('X-Sync-Bytes') || '0', 10) || buf.byteLength,
      skipped: parseInt(r.headers.get('X-Sync-Skipped') || '0', 10), running: running
    };
    if (old) await kvSet(key('prev'), old);
    await kvSet(key('snap'), rec);
    markOk(rec);
    return rec;
  }

  async function restore(snap, why) {
    setState('busy', 'Memulihkan dari HP (' + why + ')\u2026');
    var r = await api('/sync/import', { method: 'POST', headers: authH({ 'Content-Type': 'application/gzip' }), body: snap.buf }, 180000);
    var j = await r.json().catch(function () { return {}; });
    if (!r.ok) throw new Error(j.error || ('import ' + r.status));
    var list = (await listProjects()) || [];
    var want = snap.running || [];
    var ids = list.map(function (p) { return p.projectId; });
    if (want.some(function (id) { return ids.indexOf(id) < 0; })) {
      setState('warn', 'Data masuk, server belum memuat ulang', 'Sambungkan onImported di server (lihat README).', true);
      return;
    }
    var started = 0, failed = 0;
    for (var i = 0; i < want.length; i++) {
      var p = list.filter(function (x) { return x.projectId === want[i]; })[0];
      if (!p || p.runtimeStatus === 'online') continue;
      setState('busy', 'Menyalakan bot ' + (p.name || p.projectId) + '\u2026');
      try { await act(p.projectId, 'install'); await act(p.projectId, 'start'); started++; } catch (e) { failed++; }
    }
    var text = 'Dipulihkan ' + j.files + ' file' + (started ? ' \u00b7 ' + started + ' bot nyala' : '') + (failed ? ' \u00b7 ' + failed + ' gagal' : '');
    setState(failed ? 'warn' : 'ok', text, failed ? 'Cek runner (ENABLE_RUNNER) dan environment variables.' : '');
    refreshInfo(snap);
  }

  async function tick(force) {
    if (busy) return;
    if (force) st.sticky = false;
    if (!force && document.hidden) return;
    if (isNative() && !server()) { setState('idle', 'HP: belum terhubung ke server'); return; }
    if (!token()) { setState('idle', 'HP: login dulu'); return; }
    busy = true;
    try {
      var w = await wake();
      if (w.noaddon) { setState('bad', 'Server belum pasang sync-addon'); return; }
      if (w.down) { setState('bad', 'Server tidak terjangkau'); return; }
      var sr = await api('/sync/status', { headers: authH(), cache: 'no-store' }, 30000);
      if (sr.status === 401) { setState('bad', 'Token salah'); return; }
      if (sr.status === 403) { setState('bad', 'ADMIN_TOKEN belum diset di server'); return; }
      if (!sr.ok) throw new Error('status ' + sr.status);
      var s = await sr.json();
      var snap = await kvGet(key('snap'));
      // Marker beda = disk server ke-reset sejak cadangan dibuat. Pulihkan DULU, jangan pernah
      // menimpa cadangan dengan data server yang kosong.
      if (snap && snap.marker && s.marker && snap.marker !== s.marker) {
        if (Date.now() - lastAutoRestore < CFG.autoRestoreGapMs) {
          setState('warn', 'Pemulihan otomatis ditahan', 'Sudah dicoba barusan. Tekan "Pulihkan ke server" untuk mencoba lagi.');
          return;
        }
        lastAutoRestore = Date.now();
        await restore(snap, 'otomatis');
        return;
      }
      // Selama ada peringatan sticky (server belum memuat data hasil pemulihan) jangan buat cadangan baru:
      // daftar bot yang sedang jalan akan terekam kosong dan menghapus info "bot mana yang harus dinyalakan".
      showAutopilot(s.autopilot);
      if (!st.sticky && (force || !snap || Date.now() - snap.at > CFG.snapshotMs) && s.files > 1) await backup(force);
      else markOk(snap);
    } catch (e) {
      setState('bad', 'Gagal: ' + ((e && e.message) || e));
    } finally { busy = false; }
  }

  function backupNow() { return tick(true); }
  async function restoreNow() {
    var snap = await kvGet(key('snap'));
    if (!snap) { setState('warn', 'Belum ada cadangan di HP'); return; }
    if (!window.confirm('Timpa file di server dengan cadangan dari HP (' + fmtTime(snap.at) + ')?')) return;
    if (busy) return;
    st.sticky = false;
    busy = true;
    try {
      var w = await wake();
      if (!w.ok) { setState('bad', 'Server tidak terjangkau'); return; }
      await restore(snap, 'manual');
    } catch (e) {
      setState('bad', 'Gagal: ' + ((e && e.message) || e));
    } finally { busy = false; }
  }

  window.BotlaunchPhoneSync = {
    tick: tick, backupNow: backupNow, restoreNow: restoreNow,
    state: function () { return { kind: st.kind, text: st.text, detail: st.detail }; },
    meta: function () {
      return kvGet(key('snap')).then(function (s) {
        return s ? { at: s.at, marker: s.marker, files: s.files, bytes: s.bytes, running: s.running } : null;
      });
    }
  };

  function start() {
    buildUI();
    try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) { /* abaikan */ }
    setTimeout(function () { tick(false); }, CFG.firstTickMs);
    setInterval(function () { tick(false); }, CFG.tickMs);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(false); });
    window.addEventListener('online', function () { tick(false); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
