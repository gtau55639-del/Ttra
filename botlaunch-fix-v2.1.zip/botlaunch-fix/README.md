# BOTLAUNCH fix v2 — bot tetap hidup walau server free tidur/restart, tanpa HP, tanpa VPS

Paket tambalan untuk server + app BOTLAUNCH yang sudah ada. Isinya **bukan** server utamanya.

## Masalah yang diselesaikan
Server free (Render) punya dua sifat buruk: **tidur** kalau 15 menit sepi, dan **disk-nya hilang** tiap tidur/restart/redeploy. Akibatnya proyek, sesi WhatsApp, dan bot yang tadinya jalan ikut hilang.

| Lapisan | Apa yang dilakukan | Butuh server sendiri? | Butuh HP terbuka? |
|---|---|---|---|
| 1. Pinger | Membangunkan server tiap 5 menit supaya tidak tidur | Tidak (layanan gratis) | Tidak |
| 2. Otopilot (**disarankan**) | Server mencadangkan dirinya ke Cloudflare gratis; setelah disk hilang ia **pulih sendiri dan menyalakan lagi bot** | Tidak (Cloudflare Worker) | **Tidak** |
| 3. Cadangan di HP | Cadangan kedua di HP; memulihkan kalau server hilang | Tidak | Ya, app harus dibuka |

Lapisan 1 saja sudah mengurangi tidur. Untuk "jalan terus saat aku tidur" pakai **1 + 2**. Lapisan 3 pelengkap.

## Isi paket
- `server/sync-addon.js` — add-on server (tanpa dependency, Node 18+): `/api/health`, `/api/sync/*`, plus otopilot.
- `server/remote-store-worker.mjs` — kode Cloudflare Worker untuk penyimpanan luar gratis (lapisan 2).
- `.github/workflows/keepalive.yml` — pinger gratis lewat GitHub Actions (lapisan 1, cadangan dari cron-job.org).
- `.github/workflows/build-apk.yml` — build APK Android di GitHub (Vite + Capacitor).
- `app/public/phone-sync.js` — script app: cadangan di HP, bangunkan server, pulihkan otomatis (lapisan 3).
- `app/public/index.html` — contoh `index.html` hasil build dengan satu baris tambahan.
- `tests/` — 4 berkas tes (`node tests/run-all.js`).

---

## Langkah 1 — Pasang add-on di server (wajib)
1. Salin `sync-addon.js` ke folder server.
2. Di file utama server:

```js
// Express
const sync = require('./sync-addon')({ dataDir: DATA_DIR, onImported: reloadData });
app.use(sync.middleware);            // PALING ATAS, sebelum body parser
// ...
app.listen(PORT, () => { sync.start(); });   // keep-alive + otopilot, SETELAH server listen

// http mentah
if (await sync.handle(req, res)) return;     // di awal request handler
```

3. Environment variable di Render:

| Variabel | Isi |
|---|---|
| `ADMIN_TOKEN` | **Wajib**, minimal 12 karakter (kurang dari itu endpoint sync ditolak). Harus sama dengan token login app. |
| `DATA_DIR` | Folder data server (JSON proyek, workspace, sesi WhatsApp). **Harus sama** dengan folder data server kamu. |
| `SELF_URL` | Opsional. Di Render sudah otomatis dari `RENDER_EXTERNAL_URL`. |

`onImported` wajib diisi kalau server menyimpan data proyek di memori saat boot: isinya fungsi yang membaca ulang JSON dari disk. Jangan pakai `process.exit()`.

## Langkah 2 — Pinger supaya tidak tidur (wajib)
Server yang sudah tidur tidak bisa membangunkan dirinya sendiri, jadi butuh pihak luar. Pakai **dua-duanya** biar aman:
- **cron-job.org** (gratis): buat cron job ke `https://NAMA-APP.onrender.com/api/health`, tiap **5 menit** (harus < 15 menit), timeout 60 detik.
- **GitHub Actions**: salin `.github/workflows/keepalive.yml` ke repo GitHub mana pun, lalu isi variable `SERVER_URL` (Settings → Secrets and variables → Actions → Variables). Jadwal GitHub bisa telat beberapa menit, makanya jangan jadikan satu-satunya.

## Langkah 3 — Otopilot: pulih sendiri tanpa HP (disarankan)
Server mengunggah snapshot ke penyimpanan luar tiap beberapa menit **dan saat Render mematikannya (SIGTERM)**. Kalau booting dengan disk kosong, ia mengunduh snapshot, memulihkan file, lalu menyalakan lagi bot yang tadinya jalan (`install` + `start`).

**3a. Buat penyimpanan luar gratis (sekali saja, ±10 menit di dashboard Cloudflare):**
1. Daftar/login di cloudflare.com → **Workers & Pages** → **Create** → **Worker** → beri nama (mis. `botlaunch-store`) → Deploy.
2. **Edit code** → hapus isinya → tempel seluruh isi `server/remote-store-worker.mjs` → Deploy.
3. **Storage & Databases → KV** → Create namespace (mis. `botlaunch`).
4. Kembali ke Worker → **Settings → Bindings → Add → KV namespace**: *Variable name* = `STORE`, pilih namespace tadi.
5. **Settings → Variables and Secrets → Add**: tipe *Secret*, nama `TOKEN`, isi password acak panjang (minimal 12 karakter).
6. Catat alamat Worker: `https://botlaunch-store.NAMAKAMU.workers.dev/`.

(Nama menu Cloudflare bisa berubah; intinya: 1 Worker + 1 KV yang dipasang dengan nama `STORE` + 1 secret `TOKEN`.)

**3b. Isi environment di Render:**

| Variabel | Isi |
|---|---|
| `REMOTE_STORE_URL` | alamat Worker tadi |
| `REMOTE_STORE_TOKEN` | isi `TOKEN` tadi |
| `AUTO_START_BOTS` | opsional; default nyala kalau `REMOTE_STORE_URL` diisi. `false` untuk mematikan |
| `LOCAL_URL` | opsional; default `http://127.0.0.1:$PORT` (alamat server untuk memanggil dirinya sendiri) |

Penyimpanan lain (S3-proxy, WebDAV, dsb.) bisa dipakai selama mendukung `PUT` untuk unggah dan `GET` untuk unduh dengan `Authorization: Bearer`. Opsi tambahan: `REMOTE_STORE_GET_URL`, `REMOTE_STORE_PUT_METHOD` (mis. `POST`), `REMOTE_STORE_HEADERS` (JSON).

**3c. Cek jalan atau tidak:** buka `GET /api/sync/status` dengan header `Authorization: Bearer <ADMIN_TOKEN>`. Bagian `autopilot` menampilkan `recovery`, `lastUpload`, `lastError`. Log Render juga memuat baris berawalan `[sync]`.

Pengaman bawaan: server dengan disk kosong **dilarang mengunggah** sampai urusan pemulihan selesai, jadi cadangan bagus tidak pernah tertimpa data kosong; kalau penyimpanan luar sedang error, server mencoba lagi di siklus berikutnya.

## Langkah 4 — Build APK di GitHub (lapisan 3)
1. Salin `app/public/phone-sync.js` ke folder `public/` proyek web di repo kamu.
2. Salin `.github/workflows/build-apk.yml` ke repo yang sama (`.github/workflows/build-apk.yml`).
3. GitHub → tab **Actions** → **build-apk** → **Run workflow**. Tunggu ±6–10 menit.
4. Buka run yang selesai → bagian **Artifacts** → unduh **botlaunch-apk** (zip berisi `.apk`) → pasang di HP.

Workflow ini otomatis: mencari folder proyek (yang punya `capacitor.config.*`), memilih Java 17/21 sesuai versi Capacitor, menyisipkan `<script defer src="/phone-sync.js">` ke `index.html` kalau belum ada, `npm run build`, `npx cap add android` (kalau folder `android/` belum ada di repo), `npx cap sync android`, lalu Gradle.

- **Tanpa secret** → APK *debug* (langsung bisa dipasang; cukup untuk pemakaian pribadi).
- **Dengan secret keystore** → APK *release* bertanda tangan kunci kamu. Isi di Settings → Secrets and variables → Actions → Secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, opsional `ANDROID_KEY_PASSWORD`. Cara membuat keystore ada di komentar atas file workflow. **Simpan file `.jks` dan passwordnya**: kalau hilang, APK baru tidak bisa meng-update yang lama.
- Folder proyek tidak terdeteksi? Isi variable repo `APP_DIR` (mis. `app`).

Setelah APK terpasang: buka app, login. Chip kecil kiri bawah hijau "HP ✓ jam" = cadangan ada di HP. Tap chip: "Cadangkan sekarang" / "Pulihkan ke server", plus baris status otopilot server.

Catatan: workflow ini **diuji bagian-bagiannya saja** (sintaks YAML, deteksi proyek, pemilihan Java, penyisipan tag, cabang debug/release dengan Gradle dan apksigner tiruan). Build APK penuh baru terbukti saat dijalankan di GitHub; kalau gagal, log langkah yang merah menunjukkan sebabnya.

---

## Batasan (jujur)
- **Tidak ada yang bisa 100% anti-henti** di paket gratis. Saat Render restart, bot mati beberapa menit: waktu bangun (±1 menit) + `install` + `start`. Otopilot membuatnya hidup lagi sendiri, bukan tanpa jeda.
- **Sesi WhatsApp** dipulihkan dari snapshot terakhir (maks ±5 menit lebih tua, kecuali snapshot SIGTERM). Biasanya cukup; kalau WhatsApp sempat memutus perangkat, perlu pairing ulang.
- Cadangan luar berisi isi `DATA_DIR` **termasuk sesi dan rahasia**. Jaga `TOKEN` Worker; jangan bagikan. Cloudflare KV bersifat *eventually consistent*, jadi di situasi langka snapshot yang terbaca bisa sedikit lebih lama dari yang baru ditulis.
- Batas default cadangan luar 18 MB data (24 MB gzip; batas KV 25 MiB). File > 10 MB, `node_modules`, `*.log` tidak ikut. File kecil didahulukan, jadi sesi/konfigurasi tidak tergusur file besar. Atur lewat `maxFileBytes`, `maxTotalBytes`, `remoteMaxTotalBytes`, `remoteMaxBytes`.
- Cadangan di HP hanya bekerja **saat app terbuka** (timer WebView berhenti di latar belakang). Itu alasan lapisan 2 ada.
- Bot dinyalakan lewat endpoint `install` dan `start` yang ada di dashboard, jadi `ENABLE_RUNNER=true` harus aktif.
- Kuota gratis Render/Cloudflare/GitHub bisa berubah; cek batas terbaru masing-masing.

## Asumsi yang belum bisa saya uji (paket ini tidak berisi server/app utamanya)
Kode memakai kontrak API yang sama dengan yang dipakai app: `GET /api/projects` → `{projects:[{projectId, name, runtimeStatus}]}`, `POST /api/projects/:id/install|start`, status `runtimeStatus === 'online'`, token login = `ADMIN_TOKEN` (dikirim sebagai `Bearer`), dan kunci `localStorage` `botlaunch.server` / `botlaunch.token`. Semua tes memakai server tiruan dengan kontrak itu. Kalau server aslimu beda, `/api/sync/status` dan log `[sync]` akan menunjukkan di mana.

## Bug yang diperbaiki di versi ini (semua punya tes)
**Server (`sync-addon.js`)**
1. Satu request dengan URL aneh (`//[`) memunculkan *unhandled rejection* yang **mematikan server**.
2. Ekspor 36 MB data melonjak memori **+198 MB** (di batas heap 48 MB: crash OOM) → di paket free ini memicu restart lalu disk hilang lagi. Sekarang di-stream: **+43 MB**.
3. File JSON yang sedang ditulis bot (mis. `creds.json`) bisa ikut cadangan setengah jadi dan merusak sesi saat dipulihkan → sekarang dibaca ulang sampai valid.
4. Unggahan kebesaran: respons 413 sering hilang (`ECONNRESET`, gagal acak ±50%) karena koneksi ditutup saat klien masih mengirim → sekarang dikuras dulu, 30/30 sukses.
5. `ADMIN_TOKEN` pendek (mis. `abc`) diterima padahal dokumentasi minta ≥ 12 karakter.
6. Impor yang gagal/terpotong bisa meninggalkan sebagian file → sekarang atomik (file sementara dulu, baru dipasang setelah snapshot terbukti utuh). Marker dipasang paling akhir.
7. Impor lewat symlink di dalam `DATA_DIR` menolak file-nya tapi **tetap membuat folder di luar `DATA_DIR`** (terbukti); ekspor dan impor bisa berjalan bersamaan dan balapan → sekarang jalur symlink ditolak sebelum folder dibuat, dan operasi berat dikunci (429).
8. Saat batas total penuh, file yang dibuang bergantung urutan folder → sekarang file kecil (sesi, konfigurasi) didahulukan.

**HP (`phone-sync.js`)**
9. Pengaman "data server jauh lebih sedikit" tidak bisa dilewati, cadangan macet selamanya setelah kamu menghapus banyak proyek → tombol "Cadangkan sekarang" kini boleh menimpa.
10. Kalau daftar bot gagal dibaca satu kali, catatan "bot mana yang harus dinyalakan lagi" tertimpa kosong → bot tidak menyala setelah pemulihan. Sekarang catatan lama dipertahankan.
11. Server tanpa add-on salah dilaporkan "tidak terjangkau" → sekarang "belum pasang sync-addon".
12. IndexedDB yang gagal dibuka sekali macet sampai app ditutup; cadangan kemarin tampil seperti "baru saja" (jam tanpa tanggal) → diperbaiki.

## Tes
```
node tests/run-all.js          # semua
node tests/test-addon.js       # add-on: 20 tes
node tests/test-autopilot.js   # otopilot: pulih sendiri + bot menyala + SIGTERM (server & penyimpanan tiruan)
node tests/test-worker.js      # Worker + add-on ujung-ke-ujung (KV tiruan)
node tests/test-phone.js       # script HP di Chromium sungguhan (butuh: npm i -D playwright)
```
